"""Export trained model and metadata from MLflow run."""

import logging
import shutil
from pathlib import Path
from tempfile import TemporaryDirectory, mkstemp

import click
import mlflow
import mlflow.artifacts
import pandas as pd
from mlflow.exceptions import RestException


@click.command()
@click.option(
    "-o",
    "--output_dir",
    type=str,
    required=True,
    help="Output directory for the exported models.",
)
@click.option("-p", "--parent_run", type=str, required=True, help="Parent run ID or name.")
@click.option(
    "-e",
    "--experiment_name",
    type=str,
    default=None,
    help="Experiment name for filtering runs.",
)
@click.option(
    "-f",
    "--featureselection",
    type=bool,
    default=True,
    help="Enable feature selection.",
)
def export_model(output_dir, parent_run, experiment_name, featureselection):
    """Export trained model and metadata from MLflow run."""
    assert not Path(output_dir).exists(), f"Output directory {output_dir} already exists"
    assert Path(output_dir).parent.exists(), (
        f"Parent directory of output directory {output_dir} does not exist"
    )

    try:
        run = mlflow.get_run(parent_run)
    except RestException as e:
        logging.warning(f"Could not find MLflow run with ID {parent_run}: {e}, trying name lookup")
        search_all_experiments = False if experiment_name else True
        experiment_names = [experiment_name] if experiment_name else None
        runs = mlflow.search_runs(
            filter_string=f"tags.mlflow.runName = '{parent_run}'",
            search_all_experiments=search_all_experiments,
            experiment_names=experiment_names,
        )
        no_of_runs = runs.shape[0]
        assert no_of_runs > 0, f"Could not find MLflow run with name {parent_run}"
        assert no_of_runs == 1, f"Found multiple MLflow runs with name {parent_run}"
        run = mlflow.get_run(runs.iloc[0]["run_id"])
    assert run.info.status == "FINISHED", (
        f"MLflow run with ID {run.info.run_id} is not finished, status: {run.info.status}"
    )
    child_runs = mlflow.search_runs(
        filter_string=f"tags.mlflow.parentRunId = '{run.info.run_id}'",
        search_all_experiments=True,
    )
    train_run = child_runs[child_runs["tags.mlflow.project.entryPoint"] == "train"]
    assert train_run.shape[0] == 1, (
        f"Expected exactly one train run as child of {run.info.run_id}, found {train_run.shape[0]}"
    )
    train_run_id = train_run.iloc[0]["run_id"]
    train_run = mlflow.get_run(train_run_id)
    eval_run = child_runs[child_runs["tags.mlflow.project.entryPoint"] == "eval"].copy()
    eval_run.sort_values(by="start_time", inplace=True)
    eval_run["feature_selection_used"] = [True, False]
    assert eval_run.shape[0] == 2, (
        f"Expected exactly two eval runs as child of {run.info.run_id}, found {eval_run.shape[0]}"
    )
    eval_run_ids = eval_run.query("feature_selection_used == @featureselection")["run_id"]
    eval_run = mlflow.get_run(eval_run_ids.iloc[0])

    train_metrics = pd.Series(train_run.data.metrics)
    eval_metrics = pd.Series(eval_run.data.metrics)
    train_params = pd.Series(train_run.data.params)
    run_data = pd.Series(
        {
            "commit": run.data.tags.get("mlflow.source.git.commit", ""),
            "runid": run.info.run_id,
            "run_name": run.data.tags.get("mlflow.runName", ""),
            "experiment_name": mlflow.get_experiment(run.info.experiment_id).name,
            "start_time": pd.to_datetime(run.info.start_time, unit="ms"),
        }
    )
    all_data = pd.concat(
        [
            run_data,
            train_params,
            train_metrics.add_prefix("train_"),
            eval_metrics.add_prefix("eval_"),
        ]
    )

    model_id = eval_run.data.params["modelid"]
    result_path = mlflow.artifacts.download_artifacts(f"models:/{model_id}", dst_path=output_dir)
    all_data.to_csv(Path(result_path) / "model_metadata.csv")

    child_runs = mlflow.search_runs(
        filter_string=f"tags.mlflow.parentRunId = '{run.info.run_id}'",
        search_all_experiments=True,
    )
    main_run = mlflow.search_runs(
        filter_string=f"attributes.run_id = '{run.info.run_id}'",
        search_all_experiments=True,
    )
    hyper_trial_runs = mlflow.search_runs(
        filter_string=f"tags.mlflow.parentRunId = '{train_run_id}'",
        search_all_experiments=True,
    )

    all_runs = pd.concat([main_run, child_runs, hyper_trial_runs], ignore_index=True)
    all_runs.sort_values(by="start_time", inplace=True)
    all_runs.to_csv(Path(result_path) / "all_runs_metadata.csv", index=False)

    zip_temp = Path(mkstemp(suffix=".tar.gz")[1])
    with TemporaryDirectory(delete=False) as tmpdir:
        for artifact_uri, run_name in all_runs[["artifact_uri", "tags.mlflow.runName"]].itertuples(
            index=False
        ):
            dst_path = Path(tmpdir) / run_name
            all_arts = mlflow.artifacts.list_artifacts(artifact_uri)
            for art in all_arts:
                # strip /artifacts from artifact_uri
                run_uri = artifact_uri.replace("/artifacts", "")
                mlflow.artifacts.download_artifacts(f"{run_uri}/{art.path}", dst_path=dst_path)
        output_zip = Path(result_path) / "exported_runs.tgz"
        resfile = shutil.make_archive(zip_temp, "gztar", root_dir=tmpdir)
        shutil.copyfile(resfile, output_zip)
    print(f"Exported all runs to {output_zip.resolve()}")
    # Cleanup temp zip file
    print(f"Removing temporary file {zip_temp}")
    # zip_temp.unlink()


if __name__ == "__main__":
    export_model()  # pylint: disable = no-value-for-parameter
