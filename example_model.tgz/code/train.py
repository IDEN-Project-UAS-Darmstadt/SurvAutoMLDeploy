"""Train models for survival analysis."""

import gc
import importlib
import logging
import os
import pathlib
import warnings
from functools import partial
from tempfile import TemporaryDirectory

import click
import matplotlib
import mlflow
import nbformat
import numpy as np
import optuna
import pandas as pd
import papermill as pm
import plotly.express as px
import seaborn.objects as so
import timeout_decorator
from idenmodel.common import setup_logging
from idenmodel.models.common import ModelExplainer
from idenmodel.preprocessing.common import (
    convert_numeric_to_float,
    extended_km,
    log_data,
)
from joblib import Memory, dump, parallel_backend
from mlflow.sklearn.utils import _log_estimator_html
from nbconvert import HTMLExporter
from optuna.exceptions import ExperimentalWarning
from optuna.terminator import RegretBoundEvaluator, Terminator
from optuna.terminator.callback import TerminatorCallback
from optuna.terminator.erroreval import report_cross_validation_scores
from pandas.api.types import is_numeric_dtype
from pycox.evaluation import EvalSurv
from sklearn import clone, set_config
from sklearn.inspection import permutation_importance
from sklearn.model_selection import StratifiedKFold, train_test_split
from sksurv.metrics import (
    brier_score,
    concordance_index_censored,
    concordance_index_ipcw,
    cumulative_dynamic_auc,
    integrated_brier_score,
)

set_config(transform_output="pandas")
logging.getLogger("mlflow").setLevel(logging.INFO)

logger = setup_logging("Training")


def fix_risk_order(pipe, risk_score):
    """Ensure the returned risk score has the correct sign.

    Some models predict risk in the reverse ordering; this helper inverts
    the sign when the model indicates it does not use a positive risk score
    convention.
    """
    model = pipe.steps[-1][1]
    if not getattr(model, "_predict_risk_score", True):
        return risk_score * -1
    return risk_score


def infer_valid_values(df):
    """Infer valid input ranges and categorical values for each column.

    Returns a list of dicts describing expected dtype, allowed values and
    whether multiple selections are permitted. Used for serving input
    validation.
    """
    inputs = []
    for col, dtype in df.dtypes.items():
        toappend = {
            "col": col,
            "dtype": str(dtype),
            "allowmissing": bool(df[col].isna().any()),
        }
        if is_numeric_dtype(dtype):
            toappend["min"] = df[col].min()
            toappend["max"] = df[col].max()
        elif df[col].str.contains(";;").any():
            toappend["vals"] = df[col].str.split(";;").explode().value_counts().index.to_list()
            toappend["multiple"] = True
        else:
            toappend["vals"] = df[col].value_counts().index.to_list()
            toappend["multiple"] = False
        inputs.append(toappend)
    return inputs


class SurvModel(mlflow.pyfunc.PythonModel):
    """PythonModel wrapper exposing prediction and explanation helpers."""

    def __init__(self, explainer, timegrid, train_df, validate_input=True, additional_memory=None):
        """Initialize the PythonModel wrapper for a survival model.

        Args:
            explainer: ModelExplainer instance used to compute explanations.
            timegrid: Array of times at which survival functions are evaluated.
            train_df: Training DataFrame used to infer valid inputs.
            validate_input: If True, perform input validation on predict calls.
            additional_memory: Optional memory estimate used for serving.
        """
        self.validate_input = validate_input
        self._explainer = explainer
        self._input = infer_valid_values(train_df)
        self.timegrid = timegrid
        self.additional_memory = additional_memory

    @property
    def inputs(self):
        """Return the inferred input specification for the model."""
        return self._input

    @property
    def pipe(self):
        """Return the underlying sklearn pipeline used by the explainer."""
        return self._explainer.modelpipe

    def _validate_input(self, model_input):
        ins = self.inputs
        if not isinstance(model_input, pd.DataFrame):
            raise ValueError("Model input must be a pandas DataFrame.")
        if model_input.shape[1] != len(ins):
            raise ValueError(
                f"Model input must have {len(ins)} columns, but has {model_input.shape[1]}."
            )
        for inprop in ins:
            col = inprop["col"]
            if col not in model_input.columns:
                raise ValueError(f"Model input must contain column '{col}'.")
        # Any other checks are done by the model itself, so we do not need to
        # check for types or missing values here.

    def predict_survival_table(self, context, model_input):
        """Return a table of survival probabilities for each observation."""
        self._validate_input(model_input)
        survs = self.pipe.predict_survival_function(model_input)
        survs = [fn(self.timegrid) for fn in survs]
        survs = pd.DataFrame(survs, columns=[f"t{i}" for i, time in enumerate(self.timegrid)])
        survs["observation"] = np.arange(survs.shape[0])
        return survs

    def explain_survival_table(self, context, model_input, timegrid=None, or_names=True):
        """Explain predictions for the survival table using the explainer.

        Returns SHAP dataframes, the prediction and baseline along with the
        time grid used for explanation.
        """
        if timegrid is None:
            t_min = np.min(self.timegrid)
            t_max = np.max(self.timegrid)
            timegrid = np.linspace(t_min, t_max, num=3, endpoint=True)
        # shaps_dfs, target_fun, baseline_fun
        self._validate_input(model_input)
        shaps_dfs, prediction, baseline = self._explainer.explain_pred(
            timegrid, model_input, or_names=or_names
        )
        return shaps_dfs, prediction, baseline, timegrid

    def predict_risk_score(self, context, model_input):
        """Return a DataFrame of risk scores for the provided inputs."""
        self._validate_input(model_input)
        riskpred = self.pipe.predict(model_input)
        riskpred = fix_risk_order(self.pipe, riskpred)
        riskpred = pd.DataFrame(riskpred, columns=["risk_score"])
        riskpred["observation"] = np.arange(riskpred.shape[0])
        return riskpred

    def predict(self, context, model_input):
        """Return both risk predictions and survival functions."""
        self._validate_input(model_input)
        riskpred = self.pipe.predict(model_input)
        riskpred = fix_risk_order(self.pipe, riskpred)
        surv = self.pipe.predict_survival_function(model_input)
        return {"riskpred": riskpred, "surv": surv}


def restrict_test_to_train_horizon(train_y, test_y, time_field="time", event_field="event_bool"):
    """Administratively censor test-set observations whose time exceeds the
    largest observed time in the training fold, since IPCW-based metrics
    (concordance_index_ipcw, cumulative_dynamic_auc, brier_score,
    integrated_brier_score) require all survival_test times to be strictly
    smaller than max(survival_train time)."""
    test_y = np.copy(test_y)
    max_train_time = train_y[time_field].max()
    horizon = np.nextafter(max_train_time, -np.inf)
    too_late = test_y[time_field] >= horizon
    test_y[time_field][too_late] = horizon
    test_y[event_field][too_late] = False
    return test_y


@click.command()
@click.option("-m", "--modelname", required=True)
@click.option("-d", "--datafile", required=True)
@click.option("-c", "--cores", required=True, type=int)
@click.option("-s", "--seed", required=True, type=int)
@click.option("-g", "--evalgridsize", required=True, type=int)
@click.option("-t", "--trials", required=True, type=int)
def train(modelname, datafile, cores, seed, evalgridsize, trials):
    """CLI entry point to train a model specified by `modelname`.

    This command runs cross-validated training and logs results to MLflow.
    """
    with (
        mlflow.start_run(nested=True, log_system_metrics=True) as run,
        TemporaryDirectory() as temp_dir,
    ):
        logger.info("Starting training...")
        memory = Memory(location=temp_dir, verbose=0)
        model = importlib.import_module(f"idenmodel.models.{modelname}")
        df = convert_numeric_to_float(pd.read_csv(datafile))
        log_data(df, context="Train")
        mlflow.set_tag("step", "train")

        X = df.drop(columns=["time", "event"])
        y = df.loc[:, ["time", "event"]]
        y["event_bool"] = y["event"] == 1
        y = y.loc[:, ["event_bool", "time"]].to_records(index=False)
        y = np.array(y, dtype=y.dtype.descr)

        km = extended_km(y["event_bool"], y["time"])
        fig = matplotlib.figure.Figure()
        (
            so.Plot(data=km, x="time", y="surv", ymin="conf_lower", ymax="conf_upper")
            .add(so.Line())
            .add(so.Band())
            .on(fig)
            .plot()
        )
        # Run compile on matplotlib
        mlflow.log_figure(fig, "train_km.png")

        fig = px.line(km, x="time", y="n_at_risk")
        fig.update_traces(mode="lines", hovertemplate=None)
        fig.update_layout(hovermode="x unified")
        mlflow.log_figure(fig, "train_km_at_risk.html")

        def trial_name(number):
            """Return a display name for a given trial number."""
            trial_run_name = f"{run.info.run_name}-trial-{number}"
            return trial_run_name

        # Cancel long-running trials after 30 minutes
        @timeout_decorator.timeout(30 * 60, timeout_exception=optuna.TrialPruned, use_signals=True)
        def objective(trial):
            """Objective function executed by Optuna for a hyperparameter trial."""
            with mlflow.start_run(
                nested=True,
                description="Hyperparameter CV Run",
                run_name=trial_name(trial.number),
                log_system_metrics=True,
            ):
                mlflow.set_tag("step", "trial")
                mlflow.set_tag("best.trial", "false")
                pipe, needed_features = model.model_def(trial, seed)

                # print(pipe.get_params())
                pipe.set_params(memory=memory)

                cindex_harrel_folds = []
                cindex_uno_folds = []
                cindex_antolini_adj_folds = []
                timegrids = []
                mean_auc_single_folds = []
                mean_auc_cumhaz_folds = []
                auc_single_folds = []
                auc_cumhaz_folds = []
                ibs_folds = []
                brier_scores_folds = []
                fold_km_data = []
                train_time_folds = []

                cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
                for cvi, (train_index, test_index) in enumerate(cv.split(X, y["event_bool"])):
                    logger.info(f"Fitting Fold {cvi + 1}...")
                    train_x = X.iloc[train_index, :]
                    test_x = X.iloc[test_index, :]
                    train_y = np.copy(y[train_index])
                    test_y = np.copy(y[test_index])
                    # This is necessary for IPCW evaluation of metrics
                    test_y = restrict_test_to_train_horizon(train_y, test_y)

                    km_train = extended_km(train_y["event_bool"], train_y["time"])
                    km_train["Partition"] = "Train"
                    km_test = extended_km(test_y["event_bool"], test_y["time"])
                    km_test["Partition"] = "Test"
                    km = pd.concat([km_train, km_test], axis=0)
                    km["Fold"] = f"Fold {cvi + 1}"
                    fold_km_data.append(km)

                    # we start with the first event
                    min_time = np.min(test_y["time"][test_y["event_bool"]])
                    max_time = np.max(test_y["time"])
                    timegrid = np.linspace(min_time, max_time, num=evalgridsize, endpoint=False)
                    if "model__taus" in pipe.get_params():
                        pipe.set_params(model__taus=timegrid)
                    timegrids.append(timegrid)
                    start_time = pd.Timestamp.now()
                    fit = pipe.fit(train_x, train_y)
                    end_time = pd.Timestamp.now()
                    train_time_folds.append((end_time - start_time).total_seconds())
                    riskpred = fit.predict(test_x)
                    riskpred = fix_risk_order(fit, riskpred)

                    cindex_harrel = concordance_index_censored(
                        test_y["event_bool"], test_y["time"], riskpred
                    )[0]
                    cindex_harrel_folds.append(cindex_harrel)

                    cindex_uno = concordance_index_ipcw(train_y, test_y, riskpred, tau=max_time)[0]
                    cindex_uno_folds.append(cindex_uno)

                    auc_single, mean_auc_single = cumulative_dynamic_auc(
                        train_y, test_y, riskpred, timegrid
                    )
                    mean_auc_single_folds.append(mean_auc_single)
                    auc_single_folds.append(auc_single)

                    ch = fit.predict_cumulative_hazard_function(test_x)
                    ch = [fn(timegrid) for fn in ch]
                    auc_cumhaz, mean_auc_cumhaz = cumulative_dynamic_auc(
                        train_y, test_y, ch, timegrid
                    )
                    mean_auc_cumhaz_folds.append(mean_auc_cumhaz)
                    auc_cumhaz_folds.append(auc_cumhaz)
                    del ch

                    survs = fit.predict_survival_function(test_x)
                    survs = [fn(timegrid) for fn in survs]
                    brier_scores = brier_score(train_y, test_y, survs, timegrid)[1]
                    brier_scores_folds.append(brier_scores)

                    ibs = integrated_brier_score(train_y, test_y, survs, timegrid)
                    ibs_folds.append(ibs)

                    surv_df = pd.DataFrame(np.asarray(survs).T, index=timegrid)
                    ev = EvalSurv(surv_df, test_y["time"], test_y["event_bool"])
                    cindex_antolini_adj = ev.concordance_td()
                    cindex_antolini_adj_folds.append(cindex_antolini_adj)

                    logger.info(
                        "Fold %s IBS: %.3g C-Index Harrel: %.3g C-Index Uno: %.3g "
                        "AUC Risk: %.3g C-Index Antolini Adj: %.3g AUC CH: %.3g",
                        cvi + 1,
                        ibs,
                        cindex_harrel,
                        cindex_uno,
                        mean_auc_single,
                        cindex_antolini_adj,
                        mean_auc_cumhaz,
                    )

                mlflow.log_metric("Mean CV Test C-Index Harrel", np.mean(cindex_harrel_folds))
                mlflow.log_metric("Mean CV Test C-Index Uno", np.mean(cindex_uno_folds))
                mlflow.log_metric("Mean CV Test Mean AUC Risk", np.mean(mean_auc_single_folds))
                mlflow.log_metric("Mean CV Test IBS", np.mean(ibs_folds))
                mlflow.log_metric(
                    "Mean CV Test Mean AUC Cumulative Hazard",
                    np.mean(mean_auc_cumhaz_folds),
                )
                mlflow.log_metric(
                    "Mean CV Test C-Index Antolini Adj",
                    np.mean(cindex_antolini_adj_folds),
                )
                mlflow.log_metric("Mean CV Train Fit Duration Seconds", np.mean(train_time_folds))

                fold_names = [f"Test Fold {i + 1}" for i in range(len(cindex_harrel_folds))]

                auc_single_folds = pd.DataFrame(
                    list(zip(timegrids, auc_single_folds, fold_names)),
                    columns=["Time", "AUC Risk", "Fold"],
                ).explode(["Time", "AUC Risk"])
                fig = px.line(auc_single_folds, x="Time", y="AUC Risk", color="Fold")
                fig.update_traces(mode="lines", hovertemplate=None)
                fig.update_layout(hovermode="x unified")
                mlflow.log_figure(fig, "cv_auc_single.html")

                auc_cumhaz_folds = pd.DataFrame(
                    list(zip(timegrids, auc_cumhaz_folds, fold_names)),
                    columns=["Time", "AUC Cumulative Hazard", "Fold"],
                ).explode(["Time", "AUC Cumulative Hazard"])
                fig = px.line(auc_cumhaz_folds, x="Time", y="AUC Cumulative Hazard", color="Fold")
                fig.update_traces(mode="lines", hovertemplate=None)
                fig.update_layout(hovermode="x unified")
                mlflow.log_figure(fig, "cv_auc_cumhaz.html")

                # Create a bar plot of the fitting times
                fig = px.bar(
                    x=[f"Fold {i + 1}" for i in range(len(train_time_folds))],
                    y=train_time_folds,
                    labels={"x": "Fold", "y": "Fit Duration Seconds"},
                    title="Training Time per Fold",
                )
                mlflow.log_figure(fig, "cv_train_fit_time.html")

                fold_km_data = pd.concat(fold_km_data)

                for part in set(fold_km_data["Partition"]):
                    fig = matplotlib.figure.Figure()
                    sub = fold_km_data.query(f"Partition == '{part}'").reset_index(drop=True)
                    (
                        so.Plot(
                            data=sub,
                            x="time",
                            y="surv",
                            color="Fold",
                            ymin="conf_lower",
                            ymax="conf_upper",
                        )
                        .add(so.Line())
                        .add(so.Band())
                        .label(legend="Fold")
                        .on(fig)
                        .plot()
                    )
                    # Run compile on matplotlib
                    mlflow.log_figure(fig, f"cv_km_{part}.png")

                fig = px.line(
                    fold_km_data,
                    x="time",
                    y="n_at_risk",
                    color="Fold",
                    line_dash="Partition",
                )
                fig.update_traces(mode="lines", hovertemplate=None)
                fig.update_layout(hovermode="x unified")
                mlflow.log_figure(fig, "cv_km_at_risk.html")

                brier_scores_folds = pd.DataFrame(
                    list(zip(timegrids, brier_scores_folds, fold_names)),
                    columns=["Time", "Brier", "Fold"],
                ).explode(["Time", "Brier"])
                fig = px.line(brier_scores_folds, x="Time", y="Brier", color="Fold")
                fig.update_traces(mode="lines", hovertemplate=None)
                fig.update_layout(hovermode="x unified")
                mlflow.log_figure(fig, "cv_brier.html")
                report_cross_validation_scores(trial, ibs_folds)
                mlflow.log_params(trial.params)
                return np.mean(ibs_folds)

        sampler = optuna.samplers.TPESampler(
            seed=seed,
            multivariate=True,
            group=True,
            n_startup_trials=25,
            n_ei_candidates=24,
        )
        study = optuna.create_study(sampler=sampler, direction="minimize")
        with parallel_backend("loky", n_jobs=cores), warnings.catch_warnings():
            os.environ["R_RANGER_NUM_THREADS"] = str(cores)
            rbe = RegretBoundEvaluator(seed=seed)
            terminator = Terminator(min_n_trials=50, improvement_evaluator=rbe)
            study.optimize(
                objective,
                n_trials=trials,
                catch=(ValueError,),
                callbacks=[TerminatorCallback(terminator=terminator)],
                gc_after_trial=True,
            )

        mlflow.log_figure(
            optuna.visualization.plot_contour(
                study, target=lambda x: x.values[0], target_name="Mean CV Test IBS"
            ),
            "contour_ibs.html",
        )
        mlflow.log_figure(
            optuna.visualization.plot_edf(
                study, target=lambda x: x.values[0], target_name="Mean CV Test IBS"
            ),
            "edf_ibs.html",
        )
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=ExperimentalWarning)
            mlflow.log_figure(optuna.visualization.plot_timeline(study), "timeline.html")
            try:
                if len(study.trials) > 1:
                    mlflow.log_figure(
                        optuna.visualization.plot_param_importances(
                            study,
                            target=lambda x: x.values[0],
                            target_name="Mean CV Test IBS",
                        ),
                        "importance_ibs.html",
                    )
                    param_importance = optuna.importance.get_param_importances(
                        study, target=lambda x: x.values[0], normalize=True
                    )
                    mlflow.log_dict(param_importance, "param_importance_ibs.json")
            except RuntimeError as e:
                logger.warning(f"Failed to log importance plot: {e}")
            mlflow.log_figure(
                optuna.visualization.plot_parallel_coordinate(
                    study, target=lambda x: x.values[0], target_name="Mean CV Test IBS"
                ),
                "coordinate_ibs.html",
            )
            mlflow.log_figure(
                optuna.visualization.plot_optimization_history(
                    study, target=lambda x: x.values[0], target_name="Mean CV Test IBS"
                ),
                "history_ibs.html",
            )
            mlflow.log_figure(
                optuna.visualization.plot_terminator_improvement(study, plot_error=True),
                "terminator.html",
            )

        mlflow.log_param("Selection", "Best Mean CV Test IBS")
        trial = study.best_trial
        client = mlflow.client.MlflowClient()
        filter_str = (
            f"tags.mlflow.parentRunId = '{run.info.run_id}' and tags.step = 'trial'"
            f" and run_name = '{trial_name(trial.number)}'"
        )
        trial_run = client.search_runs(
            experiment_ids=[run.info.experiment_id], filter_string=filter_str
        )
        assert len(trial_run) == 1
        trial_run = trial_run[0]
        client.set_tag(trial_run.info.run_id, "best.trial", "true")
        mlflow.log_metric("Trial Number", trial.number)
        mlflow.log_params(trial.params)
        mem_history = client.get_metric_history(
            trial_run.info.run_id, "system/system_memory_usage_percentage"
        )
        mem_usage = np.fromiter((m.value for m in mem_history), dtype=np.float32)
        if len(mem_usage) > 2:
            additional_mem = (mem_usage.max() - mem_usage.min()) * 2
        else:
            additional_mem = 10.0
            # Assume at least 10% additional memory if we do not have enough
            # data.
        outer_cores = int(np.floor(100 / additional_mem))
        # TODO hardcode 1 for now; the logic sometimes leads to overallocation
        # of memory.
        outer_cores = 1
        mlflow.log_metric("Estimated Additional Memory Percentage", additional_mem)
        logger.info(
            "Using %s cores for outer parallelization based on memory usage estimation.",
            outer_cores,
        )

        pipe, needed_features = model.model_def(trial, seed)
        del study, trial, terminator, sampler
        gc.collect()
        min_time = np.min(y["time"])
        max_time = np.max(y["time"])
        timegrid = np.linspace(min_time, max_time, num=evalgridsize, endpoint=False)
        if "model__taus" in pipe.get_params():
            pipe.set_params(model__taus=timegrid)
        pipe.set_params(memory=memory)
        for featureselection in [True, False]:
            if featureselection:

                def ibs_scorer(est, X, y, y_train, ref_val=1):
                    survs = est.predict_survival_function(X)
                    timegrid = np.linspace(
                        np.min(y_train["time"]),
                        np.max(y_train["time"]),
                        num=evalgridsize,
                        endpoint=False,
                    )
                    survs = [fn(timegrid) for fn in survs]
                    score = integrated_brier_score(y_train, y, survs, timegrid)
                    return -score / ref_val

                logger.info("Starting feature selection...")
                with parallel_backend("loky", n_jobs=cores), warnings.catch_warnings():
                    os.environ["R_RANGER_NUM_THREADS"] = str(cores)
                    warnings.filterwarnings("ignore", category=UserWarning)
                    warnings.filterwarnings("ignore", category=FutureWarning)
                    X_train, X_test, y_train, y_test = train_test_split(
                        X, y, test_size=0.2, random_state=seed, stratify=y["event_bool"]
                    )
                    pipe_sel = clone(pipe).fit(X_train, y_train)
                    full_score = -ibs_scorer(pipe_sel, X_test, y_test, y_train)
                    perm_scorer = partial(ibs_scorer, y_train=y_train, ref_val=full_score)
                    permimp = permutation_importance(
                        pipe_sel,
                        X_test,
                        y_test,
                        n_repeats=5,
                        random_state=seed,
                        scoring=perm_scorer,
                        n_jobs=outer_cores,
                    )
                permimp = pd.DataFrame(
                    {
                        "Feature": pipe_sel.feature_names_in_,
                        "importances_mean": permimp["importances_mean"],
                        "importances_std": permimp["importances_std"],
                    }
                )
                permimp["ci_range"] = 1.96 * permimp["importances_std"]
                permimp["lower_ci"] = permimp["importances_mean"] - permimp["ci_range"]
                permimp = permimp.sort_values("lower_ci", ascending=False)
                mlflow.log_table(permimp, "feature_selection_permutation_importance_ibs.json")
                fig = px.bar(
                    permimp,
                    x="Feature",
                    y="importances_mean",
                    error_y="ci_range",
                    title="Permutation Importance (IBS) with 95%, 1.96 CI",
                )
                mlflow.log_figure(fig, "feature_sel_importance.html")
                selected_features = permimp.query("lower_ci > 0")["Feature"].to_list()
                logger.info(f"Selected features: {selected_features}")
                mlflow.log_metric("Selected Features", len(selected_features))
                del pipe_sel, permimp, X_train, X_test, y_train, y_test, perm_scorer
                gc.collect()
                logger.info("Fitting final model with selected features...")
            else:
                selected_features = X.columns.tolist()
                logger.info("Fitting final model with all features...")

            # Add needed features from preprocessing
            for feat in needed_features:
                if feat not in selected_features:
                    selected_features.append(feat)

            human_readable_suffix = "features_selected" if featureselection else "all_features"
            X_selected = X.loc[:, selected_features]
            with parallel_backend("loky", n_jobs=cores), warnings.catch_warnings():
                os.environ["R_RANGER_NUM_THREADS"] = str(cores)
                start_time = pd.Timestamp.now()
                pipe.fit(X_selected, y)
                end_time = pd.Timestamp.now()
                mlflow.log_metric(
                    f"Final Fit Duration Seconds {human_readable_suffix}",
                    (end_time - start_time).total_seconds(),
                )
                _log_estimator_html(run.info.run_id, pipe)
                logger.info("Model Training finished. Training Explainer...")
                explainer = ModelExplainer(pipe, seed=seed)
                explainer.fit(X_selected)

            pipe.set_params(memory=None)
            try:
                memory.clear(warn=False)
            except Exception:
                pass
            logger.info("Model Explainer finished. Constructing model artefact...")
            pyfuncmodel = SurvModel(
                explainer, timegrid, X_selected, additional_memory=additional_mem
            )
            example = X_selected.apply(
                lambda col: col.dropna().sample(1).reset_index(drop=True), axis=0
            )

            with parallel_backend("threading", n_jobs=1):
                os.environ["R_RANGER_NUM_THREADS"] = str(1)
                signature = mlflow.models.infer_signature(
                    X_selected, pyfuncmodel.predict(None, X_selected)
                )
                logger.info("Logging model artefact...")
                minfo = mlflow.pyfunc.log_model(
                    code_paths=[
                        str(codefile)
                        for codefile in pathlib.Path(__file__).parent.resolve().iterdir()
                    ],
                    name="surv_model_" + human_readable_suffix,
                    python_model=pyfuncmodel,
                    input_example=example,
                    signature=signature,
                    conda_env=str(
                        (pathlib.Path(__file__) / "../../../envs/main-exact-linux-64.yml").resolve()
                    ),
                )
                model_id = minfo.model_id
                mlflow.set_tag("modelid_" + human_readable_suffix, model_id)
                del pyfuncmodel, explainer, example, signature, X_selected
                gc.collect()
        # TODO # https://github.com/mlflow/mlflow/issues/6056

        # The notebook is meant for the complex pipeline, no manual features
        if not needed_features:
            with TemporaryDirectory() as html_render_dir:
                os.environ["PLOTLY_RENDERER"] = "notebook"
                prep = pipe.named_steps["prep"]
                dump(
                    [X, y, prep],
                    pathlib.Path(html_render_dir) / "model_pipeline.joblib",
                )
                notebook_contents = importlib.resources.read_text(
                    "idenmodel.preprocessing", "explore_features.ipynb"
                )
                with open(pathlib.Path(html_render_dir) / "explore_features.ipynb", "w") as f:
                    f.write(notebook_contents)
                # path of current file, so that the notebook finds the modules
                cur_path = pathlib.Path(__file__).parent.resolve()
                parameters = {
                    "data_path": str(pathlib.Path(html_render_dir) / "model_pipeline.joblib"),
                    "add_path": str(cur_path),
                }
                pm.execute_notebook(
                    pathlib.Path(html_render_dir) / "explore_features.ipynb",
                    pathlib.Path(html_render_dir) / "explore_features_rendered.ipynb",
                    parameters=parameters,
                )
                with open(pathlib.Path(html_render_dir) / "explore_features_rendered.ipynb") as f:
                    nb = nbformat.read(f, as_version=4)
                html_exporter = HTMLExporter()
                html_exporter.exclude_input = True
                html_exporter.template_name = "lab"
                html, _ = html_exporter.from_notebook_node(nb)
                with open(
                    pathlib.Path(html_render_dir) / "explore_features_rendered.html",
                    "w",
                ) as f:
                    f.write(html)
                mlflow.log_artifact(
                    pathlib.Path(html_render_dir) / "explore_features_rendered.html"
                )


if __name__ == "__main__":
    train()  # pylint: disable = no-value-for-parameter
