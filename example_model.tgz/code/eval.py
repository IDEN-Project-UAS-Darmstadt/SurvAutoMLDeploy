"""Evaluation module for survival models."""

import os
import warnings
from tempfile import TemporaryDirectory

import click
import matplotlib
import mlflow
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import seaborn.objects as so
from idenmodel.common import setup_logging
from idenmodel.models.calibration import (
    a_calibration,
    d_calibration,
    stratified_calibration_plot,
)
from idenmodel.models.common import bee_plot, plot_baseline_and_preds
from idenmodel.preprocessing.common import (
    convert_numeric_to_float,
    extended_km,
    log_data,
)
from joblib import parallel_backend
from pycox.evaluation import EvalSurv
from sklearn import set_config
from sklearn.inspection import permutation_importance
from sksurv.metrics import (
    brier_score,
    concordance_index_censored,
    concordance_index_ipcw,
    cumulative_dynamic_auc,
    integrated_brier_score,
)
from train import fix_risk_order

set_config(transform_output="pandas")
logger = setup_logging("Evaluation")


@click.command()
@click.option("-d", "--datafile", required=True)
@click.option("-t", "--trainfile", required=True)
@click.option("-s", "--seed", required=True, type=int)
@click.option("-g", "--evalgridsize", required=True, type=int)
@click.option("-u", "--modelid", required=True)
@click.option("-c", "--cores", required=True, type=int)
@click.option("-i", "--do_importance", required=True, type=bool)
def test(datafile, trainfile, seed, evalgridsize, modelid, cores, do_importance):
    """Evaluate a trained survival model on test data."""
    with mlflow.start_run(nested=True, log_system_metrics=True), TemporaryDirectory():
        print("Starting evaluation...")
        df = convert_numeric_to_float(pd.read_csv(datafile))
        log_data(df, context="Test")
        train_df = convert_numeric_to_float(pd.read_csv(trainfile))
        log_data(train_df, context="Train")
        mlflow.set_tag("step", "eval")

        X = df.drop(columns=["time", "event"])
        y = df.loc[:, ["time", "event"]]
        y["event_bool"] = y["event"] == 1
        y = y.loc[:, ["event_bool", "time"]].to_records(index=False)
        y = np.array(y, dtype=y.dtype.descr)

        y_train = train_df.loc[:, ["time", "event"]]
        y_train["event_bool"] = y_train["event"] == 1
        y_train = y_train.loc[:, ["event_bool", "time"]].to_records(index=False)
        y_train = np.array(y_train, dtype=y_train.dtype.descr)
        del train_df

        km = extended_km(y["event_bool"], y["time"])
        fig = matplotlib.figure.Figure()
        so.Plot(data=km, x="time", y="surv", ymin="conf_lower", ymax="conf_upper").add(
            so.Line()
        ).add(so.Band()).on(fig).plot()
        mlflow.log_figure(fig, "test_km.png")

        fig = px.line(km, x="time", y="n_at_risk")
        fig.update_traces(mode="lines", hovertemplate=None)
        fig.update_layout(hovermode="x unified")
        mlflow.log_figure(fig, "test_km_at_risk.html")

        with parallel_backend("loky", n_jobs=cores), warnings.catch_warnings():
            # set the R_RANGER_NUM_THREADS environment variable to limit threads used by ranger
            os.environ["R_RANGER_NUM_THREADS"] = str(cores)

            loaded_model = mlflow.pyfunc.load_model(f"models:/{modelid}")
            unwrapped = loaded_model.unwrap_python_model()
            X_sel = X.loc[:, unwrapped.pipe.feature_names_in_]

            min_time = np.min(y["time"])
            max_time = np.max(y["time"])
            timegrid = np.linspace(min_time, max_time, num=evalgridsize, endpoint=False)

            ch = unwrapped.pipe.predict_cumulative_hazard_function(X_sel)
            ch = [fn(timegrid) for fn in ch]
            auc_cumhaz, mean_auc_cumhaz = cumulative_dynamic_auc(y_train, y, ch, timegrid)
            del ch
            pred = loaded_model.predict(X)
            riskpred = pred["riskpred"]
            survs = pred["surv"]
            del pred

            cindex_harrel = concordance_index_censored(y["event_bool"], y["time"], riskpred)[0]
            cindex_uno = concordance_index_ipcw(y_train, y, riskpred, tau=max_time)[0]

            auc_single, mean_auc_single = cumulative_dynamic_auc(y_train, y, riskpred, timegrid)
            survs = [fn(timegrid) for fn in survs]
            brier_scores = brier_score(y_train, y, survs, timegrid)[1]
            ibs = integrated_brier_score(y_train, y, survs, timegrid)

            fake_surv_df = pd.DataFrame(np.zeros((len(X), len(timegrid))), columns=timegrid)
            tr_ev = EvalSurv(fake_surv_df, y_train["time"], y_train["event_bool"])
            surv_df = pd.DataFrame(np.asarray(survs).T, index=timegrid)
            # Note, it uses the test censsoring distribution
            ev = EvalSurv(surv_df, y["time"], y["event_bool"], censor_surv=tr_ev)
            cindex_antolini_adj = ev.concordance_td()
            del survs, fake_surv_df, surv_df

            mlflow.log_metric("Test C-Index Harrel", cindex_harrel)
            mlflow.log_metric("Test C-Index Uno", cindex_uno)
            mlflow.log_metric("Test Mean AUC", mean_auc_single)
            mlflow.log_metric("Test Mean AUC Cumulative Hazard", mean_auc_cumhaz)
            mlflow.log_metric("Test IBS", ibs)
            mlflow.log_metric("Test C-Index Antolini Adj", cindex_antolini_adj)

            timdependent_scores = pd.DataFrame(
                {
                    "Time": timegrid,
                    "AUC Risk": auc_single,
                    "AUC Cumulative Hazard": auc_cumhaz,
                    "Brier": brier_scores,
                }
            )
            mlflow.log_table(timdependent_scores, "scores.json")

            auc_single = pd.DataFrame({"Time": timegrid, "AUC Risk": auc_single})
            fig = px.line(auc_single, x="Time", y="AUC Risk")
            mlflow.log_figure(fig, "auc_single.html")

            auc = pd.DataFrame({"Time": timegrid, "AUC Cumulative Hazard": auc_cumhaz})
            fig = px.line(auc, x="Time", y="AUC Cumulative Hazard")
            mlflow.log_figure(fig, "auc_cumhaz.html")

            brier_scores = pd.DataFrame({"Time": timegrid, "Brier": brier_scores})
            fig = px.line(brier_scores, x="Time", y="Brier")
            mlflow.log_figure(fig, "brier.html")

            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=UserWarning)
                warnings.filterwarnings("ignore", category=FutureWarning)
                # Calibration plots
                calib_df = stratified_calibration_plot(
                    unwrapped.pipe, X_sel, y, q=4, time_grid=timegrid
                )
                # Simpler single-figure plot: melt pred and KM columns, label quartiles
                calib_df = calib_df.copy()
                calib_df["quartile"] = (calib_df["group"].astype(int) + 1).astype(str)
                melted = calib_df.melt(
                    id_vars=["time", "quartile"],
                    value_vars=["pred_survival", "km_survival"],
                    var_name="type",
                    value_name="survival",
                )
                melted["type"] = melted["type"].map(
                    {"pred_survival": "Predicted", "km_survival": "Kaplan-Meier"}
                )

                fig = px.line(
                    melted,
                    x="time",
                    y="survival",
                    color="quartile",
                    line_dash="type",
                    labels={
                        "time": "Time",
                        "survival": "Survival probability",
                        "quartile": "Risk Quartile",
                        "type": "Estimate",
                    },
                )
                fig.update_layout(
                    title_text="Stratified calibration by risk quartile",
                    hovermode="x unified",
                )
                fig.update_yaxes(range=[0.0, 1.0])
                mlflow.log_figure(fig, "calibration_km.html")
                mlflow.log_table(calib_df, "calibration_km.json")

                d_bin_df, d_chi_stat, d_p_val = d_calibration(
                    unwrapped.pipe, X_sel, y, group_count=10
                )
                mlflow.log_metric("D-Calibration Chi2 Stat", d_chi_stat)
                mlflow.log_metric("D-Calibration p-value", d_p_val)
                mlflow.log_table(d_bin_df, "d_calibration.json")

                a_bin_df, a_chi_stat, a_p_val = a_calibration(
                    unwrapped.pipe, X_sel, y, group_count=10
                )
                mlflow.log_metric("A-Calibration Chi2 Stat", a_chi_stat)
                mlflow.log_metric("A-Calibration p-value", a_p_val)
                mlflow.log_table(a_bin_df, "a_calibration.json")

            def ibs_scorer(est, X, y):
                survs = est.predict_survival_function(X)
                survs = [fn(timegrid) for fn in survs]
                score = integrated_brier_score(y_train, y, survs, timegrid)
                return -score / ibs

            def cuno_scorer(est, X, y):
                pred = est.predict(X)
                pred = fix_risk_order(est, pred)
                score = concordance_index_ipcw(y_train, y, pred, tau=max_time)[0]
                return score / cindex_uno

            outer_cores = 1
            if do_importance:
                logger.info("Calculating permutation importances. This may take a while...")
                logger.info(f"Using {outer_cores} cores for outer parallelization.")
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", category=UserWarning)
                    warnings.filterwarnings("ignore", category=FutureWarning)
                    permimp = permutation_importance(
                        unwrapped.pipe,
                        X_sel,
                        y,
                        n_repeats=5,
                        random_state=seed,
                        scoring={"ibs": ibs_scorer, "cuno": cuno_scorer},
                        n_jobs=outer_cores,
                    )
                result_ibs = permimp["ibs"]
                result_cindex = permimp["cuno"]

                result_df = pd.DataFrame(
                    {
                        "Feature": unwrapped.pipe.feature_names_in_,
                        "IBS Importance Mean": result_ibs.importances_mean,
                        "IBS Importance Std": result_ibs.importances_std,
                        "C-Index Uno Importance Mean": result_cindex.importances_mean,
                        "C-Index Uno Importance Std": result_cindex.importances_std,
                    }
                )
                mlflow.log_table(result_df, "importances.json")
                result_df["ibs_rank"] = result_df["IBS Importance Mean"].rank(ascending=False)
                result_df["cindex_rank"] = result_df["C-Index Uno Importance Mean"].rank(
                    ascending=False
                )
                result_df["mean_rank"] = result_df[["ibs_rank", "cindex_rank"]].mean(axis=1)
                result_df = result_df.sort_values("mean_rank")

                fig = go.Figure()
                fig.add_trace(
                    go.Bar(
                        name="Test IBS",
                        x=result_df["Feature"],
                        y=result_df["IBS Importance Mean"],
                        error_y=dict(type="data", array=result_df["IBS Importance Std"]),
                    )
                )
                fig.add_trace(
                    go.Bar(
                        name="Test C-Index Uno",
                        x=result_df["Feature"],
                        y=result_df["C-Index Uno Importance Mean"],
                        error_y=dict(type="data", array=result_df["C-Index Uno Importance Std"]),
                    )
                )
                fig.update_layout(
                    barmode="group",
                    title=dict(
                        text="Permutation Importances on Test Set (1 Std)",
                    ),
                )
                mlflow.log_figure(fig, "importances.html")

        if do_importance:
            with parallel_backend("loky", n_jobs=cores), warnings.catch_warnings():
                # set the R_RANGER_NUM_THREADS environment variable to limit threads used by ranger
                os.environ["R_RANGER_NUM_THREADS"] = str(cores)
                logger.info("Calculating SHAP values. This may also take a while...")
                Xsample = X_sel.sample(20, random_state=seed)
                log_data(Xsample, context="SHAP_Sample")
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", category=UserWarning)
                    warnings.filterwarnings("ignore", category=FutureWarning)
                    shaps_dfs, target_fun, baseline_fun, explain_timegrid = (
                        unwrapped.explain_survival_table(
                            None, Xsample, or_names=False, timegrid=timegrid
                        )
                    )
                    mlflow.log_table(shaps_dfs, "shap_values.json")
                    mlflow.log_dict(
                        {
                            "target_fun": target_fun.tolist(),
                            "baseline_fun": baseline_fun.tolist(),
                            "explain_timegrid": explain_timegrid.tolist(),
                        },
                        "shap_functions.json",
                    )
                    vals = unwrapped._explainer.scaled_values(Xsample)
                    # subtime_grid for bee plot, median (existing value), max
                    subtime_grid = [
                        explain_timegrid[len(explain_timegrid) // 2],
                        explain_timegrid[-1],
                    ]
                    subtime_grid_indices = [
                        np.where(explain_timegrid == t)[0][0] for t in subtime_grid
                    ]
                    t_labels = [f"t{i}" for i in subtime_grid_indices]
                    new_t_labels = [f"t{i}" for i in range(len(subtime_grid_indices))]
                    new_shaps_dfs = shaps_dfs.loc[
                        :, t_labels + ["aggregated_change", "observation", "variable"]
                    ].copy()
                    # Rename columns to have consecutive time labels
                    new_shaps_dfs.rename(columns=dict(zip(t_labels, new_t_labels)), inplace=True)
                    bee_fig, bee_tplt = bee_plot(subtime_grid, new_shaps_dfs, vals, n_topfeats=25)
                    mlflow.log_figure(bee_fig, "bee_fig.html")
                    mlflow.log_table(bee_tplt, "bee.json")
                    baseline_fig, baseline_tplt = plot_baseline_and_preds(
                        baseline_fun, target_fun, explain_timegrid
                    )
                    mlflow.log_figure(baseline_fig, "shap_baseline.html")
                    mlflow.log_table(baseline_tplt, "shap_baseline.json")


if __name__ == "__main__":
    test()  # pylint: disable = no-value-for-parameter
