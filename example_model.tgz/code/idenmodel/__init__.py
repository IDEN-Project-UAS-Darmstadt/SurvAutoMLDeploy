"""IDEN Model package for survival analysis."""
