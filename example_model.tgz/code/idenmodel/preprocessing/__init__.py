"""Preprocessing modules for model training and scoring."""

from . import default_preprocessing

prep_modules = [default_preprocessing]
