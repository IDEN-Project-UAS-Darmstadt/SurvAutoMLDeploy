"""Preprocessing helpers for clinical feature data."""

import os
import warnings
from functools import partial

import numpy as np
import pandas as pd
from feature_engine.selection import DropConstantFeatures, SmartCorrelatedSelection
from sklearn import set_config
from sklearn.compose import ColumnTransformer
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer, KNNImputer, SimpleImputer
from sklearn.pipeline import FunctionTransformer, Pipeline, make_pipeline
from sklearn.preprocessing import (
    OneHotEncoder,
    PowerTransformer,
    RobustScaler,
    StandardScaler,
)

from idenmodel.preprocessing.common import find_icd10_columns, icd_10_cleaning
from idenmodel.preprocessing.transformers import (
    EmbeddingEncoder,
    EmbeddingPoolEncoder,
    MultinominalEncoder,
    NASupporter,
)

set_config(transform_output="pandas")


def turn_into_object(df):
    """Convert boolean columns to object dtype for downstream processing."""
    sel = df.select_dtypes("bool")
    if sel.shape[1] == 0:
        return df
    df = df.copy()
    df[sel.columns] = sel.astype("object")
    return df


def find_features_to_transform(df):
    """Return a list of numeric feature names from the DataFrame."""
    numeric_features = df.select_dtypes(include=[np.number])
    return numeric_features.columns.to_list()


def cap_outliers(X, feature_range):
    """Clamp values outside `feature_range` to NaN and return a copy."""
    X = X.copy()
    X[(X < feature_range[0]) | (X > feature_range[1])] = np.nan
    return X


def get_feature_types(X, toget):
    """Return feature names grouped by type."""
    assert isinstance(X, pd.DataFrame), "X must be a pandas DataFrame"
    assert isinstance(toget, str), "toget must be a string"
    valid_vals = ["num", "cat", "multinominal"]
    assert toget in valid_vals, f"toget must be one of {valid_vals}"

    numbers = X.select_dtypes(["number", "bool"])
    chars = X.select_dtypes("object")
    assert (numbers.shape[1] + chars.shape[1]) == X.shape[1]

    if toget == "num":
        return numbers.columns.to_list()

    multinominal_sel = chars.apply(lambda c: c.str.contains(";;").any())

    if toget == "multinominal":
        if multinominal_sel.empty:
            return []
        return chars.loc[:, multinominal_sel].columns.to_list()
    if toget == "cat":
        if chars.empty:
            return []
        return chars.loc[:, ~multinominal_sel].columns.to_list()


def invert_col_selector(df, selector):
    """Return column names in df that are not selected by the given selector."""
    selected_cols = selector(df)
    return [col for col in df.columns if col not in selected_cols]


def name_passthrough(self, input_features=None):
    """Return the input feature names unchanged (passthrough helper)."""
    return input_features


def prep_def(trial, seed):
    """Create a preprocessing pipeline based on Optuna trial choices."""
    use_icd10 = trial.suggest_categorical("consider_icd10_embedding", [True, False])

    if use_icd10:
        embedding_path = os.getenv("ICD10_EMBEDDING_PATH", None)
        if embedding_path is None:
            warnings.warn("""ICD10_EMBEDDING_PATH is not set.
                          Will ignore ICD10 embeddings!.""")
            use_icd10 = False

    # Numeric pipeline steps
    num_steps = []
    if trial.suggest_categorical("num_consider_pt", [True, False]):
        pt = PowerTransformer(method="yeo-johnson", standardize=False)
        pt = ColumnTransformer([("pt", pt, find_features_to_transform)], remainder="passthrough")
        num_steps.append(("pt", pt))

    if trial.suggest_categorical("num_use_robust", [True, False]):
        rs = RobustScaler(with_centering=True, with_scaling=True, quantile_range=(25, 75))
        num_steps.append(("rs", rs))
        outlier_transformer = FunctionTransformer(
            cap_outliers,
            kw_args={"feature_range": (-4, 4)},
            feature_names_out=name_passthrough,
        )  # , feature_names_out="one-to-one"
        num_steps.append(("capper", outlier_transformer))

    if len(num_steps) > 0:
        num_pipe = Pipeline(num_steps)
    else:
        num_pipe = "passthrough"

    # Categorical pipelines
    max_categories = trial.suggest_int("cat_max_categories", 2, 22, step=4)
    cat_pipe = NASupporter(
        base_estimator=OneHotEncoder(
            drop="first",
            handle_unknown="infrequent_if_exist",
            min_frequency=0.01,
            max_categories=max_categories,
            sparse_output=False,
        )
    )
    if use_icd10:
        icd10_embedding_cat = NASupporter(
            EmbeddingEncoder(
                embedding_path,
                cleaning_func=icd_10_cleaning,
                n_components=max_categories,
            )
        )
        cat_pipe = ColumnTransformer(
            [
                ("icd10_emb", icd10_embedding_cat, find_icd10_columns),
                (
                    "other_cat",
                    cat_pipe,
                    partial(invert_col_selector, selector=find_icd10_columns),
                ),
            ],
            remainder="passthrough",
        )

    # Multinominal pipeline
    n_components = trial.suggest_int("multi_n_components", 2, 22, step=4)
    multinominal = make_pipeline(
        NASupporter(MultinominalEncoder(n_components=n_components, random_state=seed))
    )
    if use_icd10:
        pooling = trial.suggest_categorical("icd10_pooling", ["mean", "max", "sum"])
        icd10_pool = NASupporter(
            EmbeddingPoolEncoder(
                embedding_path,
                pooling=pooling,
                cleaning_func=icd_10_cleaning,
                n_components=n_components,
            )
        )
        multinominal = ColumnTransformer(
            [
                ("icd10_pool", icd10_pool, find_icd10_columns),
                (
                    "other_multinominal",
                    multinominal,
                    partial(invert_col_selector, selector=find_icd10_columns),
                ),
            ],
            remainder="passthrough",
        )

    ct = ColumnTransformer(
        [
            ("num", num_pipe, partial(get_feature_types, toget="num")),
            (
                "cat",
                cat_pipe,
                partial(get_feature_types, toget="cat"),
            ),
            (
                "multinominal",
                multinominal,
                partial(get_feature_types, toget="multinominal"),
            ),
        ],
        remainder="passthrough",
    )

    fixbools = FunctionTransformer(
        turn_into_object, feature_names_out=name_passthrough
    )  # feature_names_out="one-to-one" is leading to problems when passing DataFrames around
    steps = [
        ("fixbools", fixbools),
        ("dropc", DropConstantFeatures(missing_values="ignore")),
        ("ct", ct),
    ]

    steps.append(("pre_imputer_sc", StandardScaler()))

    imputer = trial.suggest_categorical("imputer", ["mean", "knn", "iterative"])
    if imputer == "mean":
        # remove pre_imputer_sc:
        steps.pop(-1)
        steps.append(("imputer", SimpleImputer()))
    elif imputer == "knn":
        imputer_n_neighbors = trial.suggest_int("n_neighbors", 3, 11, step=2)
        steps.append(("imputer", KNNImputer(n_neighbors=imputer_n_neighbors)))
    elif imputer == "iterative":
        steps.append(
            (
                "imputer",
                IterativeImputer(random_state=seed, verbose=10, n_nearest_features=10),
            )
        )

    steps.append(("post_imputer_sc", StandardScaler()))

    if trial.suggest_categorical("filter_correlated", [True, False]):
        steps.append(
            (
                "sel",
                SmartCorrelatedSelection(
                    threshold=0.8,
                    method="spearman",
                    missing_values="ignore",
                    selection_method="cardinality",
                    estimator=None,
                ),
            )
        )

    pipe = Pipeline(steps)

    return pipe, []
