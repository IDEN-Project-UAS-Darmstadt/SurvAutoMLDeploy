"""Preprocessing transformers for clinical feature data."""

import warnings

import numpy as np
import pandas as pd
from feature_engine._check_init_parameters.check_variables import (
    _check_variables_input_value,
)
from feature_engine.dataframe_checks import check_X
from feature_engine.selection.base_selection_functions import _select_all_variables
from feature_engine.selection.base_selector import BaseSelector
from feature_engine.selection.drop_constant_features import Variables
from sklearn import set_config
from sklearn.base import BaseEstimator, TransformerMixin, clone
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.utils import _safe_indexing, check_array
from sklearn.utils.validation import (
    _check_feature_names,
    _check_feature_names_in,
    _check_n_features,
    check_is_fitted,
    validate_data,
)

set_config(transform_output="pandas")


def split_and_filter(x):
    """Split a multi-value string on `;;` and remove empty entries."""
    split = x.split(";;")
    filtered = [s for s in split if s != ""]
    return filtered


class MultinominalEncoder(TransformerMixin, BaseEstimator):
    """Encode multinomial text feature with per-column SVD projections."""

    def __init__(self, n_components=2, random_state=None):
        """Store encoder hyperparameters."""
        self.random_state = random_state
        self.n_components = n_components

    def fit(self, X, y=None):
        """Fit one vectorizer and per-column reduction on non-missing rows.

        The encoder operates column-wise and preserves missing rows by emitting
        NaN blocks for them during transform. For each input column we fit a
        CountVectorizer on the non-missing values and optionally a TruncatedSVD
        on the resulting count matrix.
        """
        X = validate_data(self, X, dtype=object, ensure_all_finite=False)
        n_features = X.shape[1]
        input_features = _check_feature_names_in(self)
        if input_features is None:
            input_features = np.array([f"x{i}" for i in range(n_features)], dtype=object)

        self.n_features_in_ = n_features
        self._vectorizers = []
        self._projectors = []
        self._n_outputs_per_column = []
        self._feature_names_per_column = []

        for idx in range(n_features):
            Xi = X[:, idx]
            non_missing = ~pd.isna(Xi)
            if not np.any(non_missing):
                raise ValueError(
                    f"Column index {idx} contains only missing values and cannot be fitted."
                )

            docs = np.asarray(Xi[non_missing]).reshape(-1)
            vectorizer = CountVectorizer(
                analyzer=split_and_filter, lowercase=False, dtype=np.float64
            )
            counts = vectorizer.fit_transform(docs)
            vocab_size = len(vectorizer.get_feature_names_out())

            projector = None
            n_outputs = vocab_size
            if self.n_components is not None and vocab_size > 1:
                n_components = min(int(self.n_components), vocab_size)
                if n_components > 0:
                    projector = TruncatedSVD(
                        n_components=n_components,
                        random_state=self.random_state,
                    )
                    projector.fit(counts)
                    n_outputs = n_components

            self._vectorizers.append(vectorizer)
            self._projectors.append(projector)
            self._n_outputs_per_column.append(int(n_outputs))
            self._feature_names_per_column.append(
                vectorizer.get_feature_names_out(input_features=[input_features[idx]])
            )

        return self

    def transform(self, X):
        """Transform each input feature into its low-dimensional embedding."""
        check_is_fitted(self, "_vectorizers")
        X = validate_data(self, X, dtype=object, ensure_all_finite=False, reset=False)
        _check_feature_names(self, X, reset=False)
        _check_n_features(self, X, reset=False)

        res = []
        for idx in range(X.shape[1]):
            Xi = X[:, idx]
            missing = pd.isna(Xi)
            n_outputs = int(self._n_outputs_per_column[idx])
            block = np.full((X.shape[0], n_outputs), np.nan, dtype=np.float64)

            non_missing = ~missing
            if np.any(non_missing):
                docs = np.asarray(Xi[non_missing]).reshape(-1)
                counts = self._vectorizers[idx].transform(docs)
                projector = self._projectors[idx]
                if projector is not None:
                    transformed = projector.transform(counts)
                else:
                    transformed = counts.toarray()
                transformed = np.asarray(transformed)
                if transformed.ndim == 1:
                    transformed = transformed.reshape(-1, 1)
                block[non_missing, :] = transformed

            res.append(block)

        return np.hstack(res)

    def get_feature_names_out(self, input_features=None):
        """Return output feature names for the fitted embeddings.

        Build names from the cached truncated SVDs so we avoid delegating to
        pipeline internals. Each fitted SVD contributes `n_components` names
        prefixed by the corresponding input feature name.
        """
        check_is_fitted(self, "_vectorizers")
        input_features = _check_feature_names_in(self, input_features)

        feature_names = []
        for idx, projector in enumerate(self._projectors):
            if projector is not None:
                n_comp = int(projector.n_components)
                feature_names.extend([f"{input_features[idx]}_{j}" for j in range(n_comp)])
            else:
                feature_names.extend(self._feature_names_per_column[idx])

        return np.array(feature_names, dtype=object)


class NASupporter(TransformerMixin, BaseEstimator):
    """Wrap a base transformer and preserve NA rows in derived feature blocks.

    The wrapped base estimator is cloned and fitted once per input column,
    using only non-missing values of that column. During transform, rows with
    missing input values receive NaN for the full derived feature block of the
    corresponding input column.
    """

    def __init__(self, base_estimator):
        """Initialize the wrapper with the transformer to clone per column."""
        self.base_estimator = base_estimator

    def _check_X(self, X, ensure_all_finite=True):
        """Validate X and return one array per feature column."""
        if not (hasattr(X, "iloc") and getattr(X, "ndim", 0) == 2):
            X = check_array(X, dtype=None, ensure_all_finite=ensure_all_finite)
            needs_validation = False
        else:
            needs_validation = ensure_all_finite

        n_samples, n_features = X.shape
        X_columns = []
        for i in range(n_features):
            Xi = _safe_indexing(X, indices=i, axis=1)
            Xi = check_array(Xi, ensure_2d=False, dtype=None, ensure_all_finite=needs_validation)
            X_columns.append(Xi)
        return X_columns, n_samples, n_features

    @staticmethod
    def _as_2d_array(values):
        """Convert transformer outputs into a dense 2D NumPy array."""
        if hasattr(values, "toarray"):
            values = values.toarray()
        elif hasattr(values, "values"):
            values = values.values
        arr = np.asarray(values)
        if arr.ndim == 1:
            arr = arr.reshape(-1, 1)
        return arr

    def fit(self, X, y=None):
        """Fit one clone of the base estimator per column on non-missing rows."""
        _check_n_features(self, X, reset=True)
        _check_feature_names(self, X, reset=True)
        X_list, _, n_features = self._check_X(X, ensure_all_finite=False)
        self.n_features_in_ = n_features

        self._column_transformers = []
        self._n_outputs_per_column = []

        for idx in range(n_features):
            Xi = X_list[idx]
            non_missing = ~pd.isna(Xi)
            if not np.any(non_missing):
                raise ValueError(
                    f"Column index {idx} contains only missing values and cannot be fitted."
                )

            Xi_non_missing = Xi[non_missing].reshape(-1, 1)
            transformer = clone(self.base_estimator)
            transformer.fit(Xi_non_missing)

            sample_out = transformer.transform(Xi_non_missing[:1])
            n_outputs = self._as_2d_array(sample_out).shape[1]

            self._column_transformers.append(transformer)
            self._n_outputs_per_column.append(n_outputs)

        return self

    def transform(self, X):
        """Transform each column and set derived rows for missing inputs to NaN."""
        check_is_fitted(self, "_column_transformers")
        X_list, n_samples, n_features = self._check_X(X, ensure_all_finite=False)
        _check_feature_names(self, X, reset=False)
        _check_n_features(self, X, reset=False)

        res = []
        for idx in range(n_features):
            Xi = X_list[idx]
            missing = pd.isna(Xi)
            n_outputs = int(self._n_outputs_per_column[idx])
            block = np.full((n_samples, n_outputs), np.nan, dtype=np.float64)

            non_missing = ~missing
            if np.any(non_missing):
                Xi_non_missing = Xi[non_missing].reshape(-1, 1)
                transformed = self._column_transformers[idx].transform(Xi_non_missing)
                transformed = self._as_2d_array(transformed)
                block[non_missing, :] = transformed

            res.append(block)

        return np.hstack(res)

    def get_feature_names_out(self, input_features=None):
        """Return delegated output feature names from each column transformer."""
        check_is_fitted(self, "_column_transformers")
        input_features = _check_feature_names_in(self, input_features)

        feature_names = []
        for idx, transformer in enumerate(self._column_transformers):
            names = transformer.get_feature_names_out([input_features[idx]])
            feature_names.extend(names)
        return np.array(feature_names, dtype=object)

    def get_feature_names(self, input_features=None):
        """Compatibility alias forwarding to get_feature_names_out."""
        return self.get_feature_names_out(input_features=input_features)


class DropMissingFeatures(BaseSelector):
    """Drop features whose missing-value rate exceeds a threshold."""

    def __init__(
        self,
        *,
        variables: Variables = None,
        tol: float = 0.5,
        confirm_variables: bool = False,
    ):
        """Initialize the selector with the configured missingness threshold."""
        if not isinstance(tol, (float, int)) or isinstance(tol, bool) or tol < 0 or tol > 1:
            raise ValueError("tol must be a float or integer between 0 and 1")

        super().__init__(confirm_variables)

        self.tol = tol
        self.variables = _check_variables_input_value(variables)

    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        """Identify columns to drop based on the configured threshold."""
        X = check_X(X)

        self.variables_ = _select_all_variables(X, self.variables, self.confirm_variables)

        self.features_to_drop_ = X.columns[X.isna().sum(axis=0) / X.shape[0] >= self.tol].to_list()

        # check we are not dropping all the columns in the df
        if len(self.features_to_drop_) == len(X.columns):
            raise ValueError(
                "The resulting dataframe will have no columns after dropping all "
                "constant or quasi-constant features. Try changing the tol value."
            )
        # save input features
        self._get_feature_names_in(X)
        return self


class EmbeddingPoolEncoder(TransformerMixin, BaseEstimator):
    """Pool embeddings for columns containing lists/sequences of codes.

    Looks up each code's embedding and pools them (mean by default) into a
    single vector per row.
    """

    def __init__(self, embedding_path, pooling="mean", cleaning_func=None, n_components=None):
        """Initialize the encoder.

        If `n_components` is set and smaller than the dimensionality, a
        TruncatedSVD reducer is fit on and used to
        project vectors during transform.
        """
        self.embedding_path = embedding_path
        self.pooling = pooling
        self.cleaning_func = cleaning_func
        self.n_components = n_components
        self._reducer = None

    def _load(self):
        """Load embedding matrix and code-to-index mapping from file."""
        if not hasattr(self, "_matrix"):
            data = np.load(self.embedding_path, allow_pickle=True)
            self._matrix = data["matrix"].astype(np.float32)
            self._code2idx = {c: i for i, c in enumerate(data["codes"])}
            self._n_dims = self._matrix.shape[1]
            # decide output dimensionality and prepare reducer placeholder
            self._output_dims = int(self._n_dims)

    def _transform_full(self, X):
        X = validate_data(self, X, dtype=object, ensure_all_finite=False, reset=False)
        input_features = _check_feature_names_in(self)
        n_features = X.shape[1]
        res = []
        for i in range(n_features):
            Xi = X[:, i]
            col_name = input_features[i] if input_features is not None else f"x{i}"
            Xi = pd.Series(Xi, name=col_name).str.split(";;")
            unknown_codes = set()
            out_rows = []
            for val in Xi:
                if self.cleaning_func is not None and not self._is_missing(val):
                    val = self.cleaning_func(val)
                if self._is_missing(val):
                    out_rows.append(np.full(self._n_dims, np.nan, dtype=np.float32))
                    continue

                unknown_codes.update(c for c in val if c not in self._code2idx)
                known = [c for c in val if c in self._code2idx]
                if not known:
                    out_rows.append(np.full(self._n_dims, np.nan, dtype=np.float32))
                else:
                    vecs = self._matrix[[self._code2idx[c] for c in known]]
                    if self.pooling == "mean":
                        out_rows.append(np.nanmean(vecs, axis=0))
                    elif self.pooling == "max":
                        out_rows.append(np.nanmax(vecs, axis=0))
                    elif self.pooling == "sum":
                        out_rows.append(np.nansum(vecs, axis=0))
            if unknown_codes:
                warnings.warn(
                    f"Column {col_name!r}: {len(unknown_codes)} unknown code(s) encountered "
                    f"(will produce NaN rows): {sorted(unknown_codes)}",
                    UserWarning,
                    stacklevel=2,
                )
            res.append(np.vstack(out_rows))
        return np.hstack(res)

    def fit(self, X, y=None):
        """Fit the encoder by loading embeddings and validating input data."""
        self._load()
        validate_data(self, X, dtype=object, ensure_all_finite=False)
        if self.n_components is not None:
            if int(self.n_components) <= 0:
                raise ValueError("n_components must be a positive integer or None")
            if int(self.n_components) < self._n_dims:
                transformed = self._transform_full(X)
                # remove nan rows before fitting reducer
                finite_mask = ~np.isnan(transformed).all(axis=1)
                self._reducer = PCA(n_components=int(self.n_components))
                self._reducer.fit(transformed[finite_mask])
                self._output_dims = int(self.n_components)
            else:
                # requested components >= original dims -> no reduction
                self._reducer = None
                self._output_dims = int(self._n_dims)
        return self

    def _is_missing(self, val):
        """Check if a value is missing or empty."""
        if hasattr(val, "__iter__") and not isinstance(val, str):
            return len(val) == 0 or pd.isna(list(val)).all()
        return pd.isna(val)

    def transform(self, X):
        """Transform each column by pooling embeddings of codes in each row."""
        res = self._transform_full(X)
        # reduce dimensionality if reducer is available
        if self._reducer is not None:
            finite_mask = ~np.isnan(res).all(axis=1)
            reduced = np.full((res.shape[0], self._output_dims), np.nan, dtype=np.float32)
            if np.any(finite_mask):
                reduced[finite_mask, :] = self._reducer.transform(res[finite_mask])
            return reduced
        else:
            return res

    def get_feature_names_out(self, input_features=None):
        """Return output feature names for the fitted embeddings."""
        check_is_fitted(self)
        input_features = _check_feature_names_in(self, input_features)
        feature_names = []
        for col in input_features:
            feature_names.extend([f"{col}_emb_{i}" for i in range(self._output_dims)])
        return np.array(feature_names, dtype=object)


class EmbeddingEncoder(TransformerMixin, BaseEstimator):
    """Look up embeddings for columns containing a single code per row.

    (Multi column support is broken, use NASupporter)
    """

    def __init__(self, embedding_path, cleaning_func=None, n_components=None):
        """Initialize the encoder with embedding path, optional cleaning and reduction.

        If `n_components` is set, a PCA reducer is fit on the actual lookup results
        during fit and used to project vectors during transform.
        """
        self.embedding_path = embedding_path
        self.cleaning_func = cleaning_func
        self.n_components = n_components
        self._reducer = None

    def _load(self):
        """Load embedding matrix and code-to-index mapping from file."""
        if not hasattr(self, "_matrix"):
            data = np.load(self.embedding_path, allow_pickle=True)
            self._matrix = data["matrix"].astype(np.float32)
            self._code2idx = {c: i for i, c in enumerate(data["codes"])}
            self._n_dims = self._matrix.shape[1]
            self._output_dims = int(self._n_dims)

    def _transform_full(self, X):
        """Look up embeddings for all codes without reduction."""
        X = validate_data(self, X, dtype=object, ensure_all_finite=False, reset=False)
        input_features = _check_feature_names_in(self)
        res = []
        n_features = X.shape[1]
        for i in range(n_features):
            Xi = X[:, i]
            col_name = input_features[i] if input_features is not None else f"x{i}"
            if self.cleaning_func is not None:
                Xi = self.cleaning_func(Xi)
            missing = pd.isna(Xi)
            unknown_codes = {
                Xi[j] for j in range(len(Xi)) if not missing[j] and Xi[j] not in self._code2idx
            }
            if unknown_codes:
                warnings.warn(
                    f"Column {col_name!r}: {len(unknown_codes)} unknown code(s) encountered "
                    f"(will produce NaN rows): {sorted(unknown_codes)}",
                    UserWarning,
                    stacklevel=2,
                )
            out_rows = [
                (
                    np.full(self._n_dims, np.nan, dtype=np.float32)
                    if missing[j] or Xi[j] not in self._code2idx
                    else self._matrix[self._code2idx[Xi[j]]]
                )
                for j in range(len(Xi))
            ]
            res.append(np.vstack(out_rows))
        return np.hstack(res)

    def fit(self, X, y=None):
        """Fit the encoder by loading embeddings and validating input data."""
        self._load()
        validate_data(self, X, dtype=object, ensure_all_finite=False)
        if self.n_components is not None:
            if int(self.n_components) <= 0:
                raise ValueError("n_components must be a positive integer or None")
            if int(self.n_components) < self._n_dims:
                transformed = self._transform_full(X)
                # remove nan rows before fitting reducer
                finite_mask = ~np.isnan(transformed).all(axis=1)
                self._reducer = PCA(n_components=int(self.n_components))
                self._reducer.fit(transformed[finite_mask])
                self._output_dims = int(self.n_components)
            else:
                # requested components >= original dims -> no reduction
                self._reducer = None
                self._output_dims = int(self._n_dims)
        return self

    def transform(self, X):
        """Transform each column by looking up the embedding for each code."""
        res = self._transform_full(X)
        # reduce dimensionality if reducer is available
        if self._reducer is not None:
            finite_mask = ~np.isnan(res).all(axis=1)
            reduced = np.full((res.shape[0], self._output_dims), np.nan, dtype=np.float32)
            if np.any(finite_mask):
                reduced[finite_mask, :] = self._reducer.transform(res[finite_mask])
            return reduced
        else:
            return res

    def get_feature_names_out(self, input_features=None):
        """Return output feature names for the fitted embeddings."""
        check_is_fitted(self)
        input_features = _check_feature_names_in(self, input_features)
        feature_names = []
        for col in input_features:
            feature_names.extend([f"{col}_emb_{i}" for i in range(self._output_dims)])
        return np.array(feature_names, dtype=object)
