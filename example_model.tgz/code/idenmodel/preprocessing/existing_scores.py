"""Helpers to compute and transform existing clinical scores.

This module implements KDRI, raw EPTS and DGF risk computations and
convenience transformers to apply them to pandas DataFrames.
"""

from functools import partial

import numpy as np
import pandas as pd

# sklearn use pandas
from sklearn import set_config
from sklearn.impute import SimpleImputer
from sklearn.pipeline import FeatureUnion, FunctionTransformer, Pipeline, make_pipeline
from sklearn.preprocessing import StandardScaler

set_config(transform_output="pandas")


DIABETES_CODES = ["E10", "E11", "E13", "E14"]
CVA_CODES = ["I60", "I61", "I62", "I63", "I64", "I65", "I66", "I67", "I68", "I69"]
CARDIAC_DEATH_CODES = ["I20", "I21", "I22", "I23", "I24", "I25", "I50"]
ANOXIA_CODES = [
    "G93.1",
    "R09.0",
    "T71",
    "X70",
    "X91",
    "G93",
    "T75",
    "X70",
    "X71",
    "X91",
] + [f"W{i}" for i in range(65, 85)]


def kdri(
    age,
    african_american,
    creatinine,
    hypertensive,
    diabetic,
    cause_cva,
    height_cm,
    weight_kg,
    dcd,
    hcv,
    hla_b_mismatch,  # 0, 1 or 2 (2 = reference)
    hla_dr_mismatch,  # 0, 1 (ref), or 2
    cold_ischemia_hours,
    en_bloc=False,
    double_kidney=False,
):
    """Compute KDRI score and return a single-column DataFrame.

    The function accepts array-like inputs for donor/recipient features
    and returns a DataFrame with column `kdri`.
    """
    # Convert all inputs to arrays
    age = np.asarray(age)
    creatinine = np.asarray(creatinine)
    height_cm = np.asarray(height_cm)
    weight_kg = np.asarray(weight_kg)
    cold_ischemia_hours = np.asarray(cold_ischemia_hours)

    african_american = np.asarray(african_american)
    hypertensive = np.asarray(hypertensive)
    diabetic = np.asarray(diabetic)
    cause_cva = np.asarray(cause_cva)
    dcd = np.asarray(dcd)
    hcv = np.asarray(hcv)
    hla_b_mismatch = np.asarray(hla_b_mismatch)
    hla_dr_mismatch = np.asarray(hla_dr_mismatch)
    en_bloc = np.asarray(en_bloc)
    double_kidney = np.asarray(double_kidney)

    # Start linear predictor
    L = np.zeros_like(age, dtype=float)

    # Age ≤ 18
    L += 0.0194 * np.where(age <= 18, age - 18, 0)

    # Age − 40 (all ages)
    L += 0.0128 * (age - 40)

    # Age ≥ 50
    L += 0.0107 * np.where(age >= 50, age - 50, 0)

    # Race
    L += 0.179 * african_american

    # Hypertension
    L += 0.126 * hypertensive

    # Diabetes
    L += 0.130 * diabetic

    # Creatinine terms
    L += 0.220 * (creatinine - 1)
    L += -0.209 * np.where(creatinine >= 1.5, creatinine - 1.5, 0)

    # Cause of death: CVA
    L += 0.0881 * cause_cva

    # Height: (height − 170)/10
    L += 0.0464 * ((height_cm - 170) / 10)

    # Weight < 80 kg
    L += 0.0199 * np.where(weight_kg < 80, (weight_kg - 80) / 5, 0)

    # Donation after cardiac death
    L += 0.133 * dcd

    # HCV+
    L += 0.240 * hcv

    # HLA-B mismatches
    L += 0.0766 * (hla_b_mismatch == 0)
    L += 0.0610 * (hla_b_mismatch == 1)

    # HLA-DR mismatches
    L += 0.130 * (hla_dr_mismatch == 0)
    L += 0.0765 * (hla_dr_mismatch == 2)

    # CIT
    L += 0.00548 * (cold_ischemia_hours - 20)

    # Special graft types
    L += 0.364 * en_bloc
    L += 0.148 * double_kidney

    # Final KDRI
    return pd.DataFrame({"kdri": np.exp(L)})


def raw_epts(age, diabetes, prior_transplant, years_on_dialysis):
    """Compute raw EPTS score and return a single-column DataFrame."""
    # Convert inputs to numpy arrays
    age = np.asarray(age)
    diabetes = np.asarray(diabetes)
    prior_transplant = np.asarray(prior_transplant)
    years_on_dialysis = np.asarray(years_on_dialysis)

    # Age term
    age_term = 0.047 * np.maximum(age - 25, 0) - 0.015 * diabetes * np.maximum(age - 25, 0)

    # Prior transplant term
    transplant_term = 0.398 * prior_transplant - 0.237 * diabetes * prior_transplant

    # Dialysis term
    dialysis_term = 0.315 * np.log(years_on_dialysis + 1) - 0.099 * diabetes * np.log(
        years_on_dialysis + 1
    )

    # Zero dialysis adjustment
    zero_dialysis = (years_on_dialysis == 0).astype(float)
    zero_dialysis_term = 0.130 * zero_dialysis - 0.348 * diabetes * zero_dialysis

    # Diabetes main effect
    diabetes_term = 1.262 * diabetes

    # Sum all terms
    raw_epts_score = age_term + transplant_term + dialysis_term + zero_dialysis_term + diabetes_term
    return pd.DataFrame({"raw_epts": raw_epts_score})


# https://www.amjtransplant.org/article/S1600-6135(22)14438-2/fulltext
def dgf_risk_irish(
    # Recipient parameters
    recipient_black,
    recipient_male,
    recipient_previous_transplant,
    recipient_diabetes,
    deltamax_pra,
    recipient_pretransplant_transfusions,
    recipient_hla_mismatches,
    recipient_bmi,
    recipient_dialysis_days,
    # Donor parameters
    donor_age,
    cold_ischemia_hours,
    warm_ischemia_minutes,
    donor_dcd,
    donor_hypertension,
    donor_creatinine_mg_dl,
    donor_cause_anoxia,
    donor_cause_cva,
    donor_weight_kg,
):
    """Compute DGF Irish risk score and return a single-column DataFrame."""
    # Convert all inputs to arrays
    recipient_black = np.asarray(recipient_black)
    recipient_male = np.asarray(recipient_male)
    recipient_previous_transplant = np.asarray(recipient_previous_transplant)
    recipient_diabetes = np.asarray(recipient_diabetes)
    deltamax_pra = np.asarray(deltamax_pra)
    recipient_pretransplant_transfusions = np.asarray(recipient_pretransplant_transfusions)
    recipient_hla_mismatches = np.asarray(recipient_hla_mismatches)
    recipient_bmi = np.asarray(recipient_bmi)
    recipient_dialysis_days = np.asarray(recipient_dialysis_days)

    donor_age = np.asarray(donor_age)
    cold_ischemia_hours = np.asarray(cold_ischemia_hours)
    warm_ischemia_minutes = np.asarray(warm_ischemia_minutes)
    donor_dcd = np.asarray(donor_dcd)
    donor_hypertension = np.asarray(donor_hypertension)
    donor_creatinine_mg_dl = np.asarray(donor_creatinine_mg_dl)
    donor_cause_anoxia = np.asarray(donor_cause_anoxia)
    donor_cause_cva = np.asarray(donor_cause_cva)
    donor_weight_kg = np.asarray(donor_weight_kg)

    # Start linear predictor
    L = np.zeros_like(recipient_black, dtype=float)

    # Recipient factors
    L += 0.235 * recipient_black
    L += 0.375 * recipient_male
    L += 0.134 * recipient_previous_transplant
    L += 0.277 * recipient_diabetes
    L += 0.003 * deltamax_pra  # not exactly a fit
    L += 0.225 * recipient_pretransplant_transfusions
    L += 0.045 * recipient_hla_mismatches
    L += 0.042 * recipient_bmi
    L += 0.00051 * recipient_dialysis_days
    L += -6.26e-8 * (recipient_dialysis_days**2)

    # Donor factors
    L += 0.017 * np.maximum(donor_age - 16, 0)
    L += 0.040 * cold_ischemia_hours
    L += 0.007 * warm_ischemia_minutes
    L += 1.119 * donor_dcd
    L += 0.265 * donor_hypertension
    L += 0.526 * donor_creatinine_mg_dl
    L += 0.204 * donor_cause_anoxia
    L += 0.191 * donor_cause_cva
    L += -0.011 * donor_weight_kg
    L += 0.00009 * (donor_weight_kg**2)

    # Return odds ratio
    return pd.DataFrame({"dgf_risk": L})


def contains_code(codes, target_code_prefixes):
    """Return True if any code in `codes` starts with a target prefix."""
    missing = pd.isna(codes)
    if hasattr(missing, "all"):
        missing = missing.all()
    else:
        missing = bool(missing)
    if missing:
        return np.nan
    # if it is a string, convert to list
    if isinstance(codes, str):
        codes = [codes]
    for prefix in target_code_prefixes:
        for code in codes:
            if code.startswith(prefix):
                return 1
    return 0


def construct_kdri_df_names(transformer, feature_names_in):
    """Return output feature names for the KDRI transformer."""
    return [
        "age",
        "african_american",
        "creatinine",
        "hypertensive",
        "diabetic",
        "cause_cva",
        "height_cm",
        "weight_kg",
        "dcd",
        "hcv",
        "hla_b_mismatch",
        "hla_dr_mismatch",
        "cold_ischemia_hours",
        "en_bloc",
        "double_kidney",
    ]


def construct_kdri_df(X):
    """Construct donor/recipient features required for KDRI scoring."""
    age = X["donor_age"]
    # This is unavailable in TxReg data
    african_american = np.repeat(False, X.shape[0])
    # Convert to mg/dL
    creatinine = X["donor_chem_creatinine_umol_per_l"] / 88.4
    # Pandas treats NAs as their own values
    hypertensive = (X["donor_hypertension"] == "yes") * 1.0
    hypertensive[X["donor_hypertension"].isna()] = np.nan
    all_codes = X["donor_diagnosis_icd10"].str.split(";;")
    diabetic = all_codes.apply(lambda codes: contains_code(codes, DIABETES_CODES))
    cause_cva = all_codes.apply(lambda codes: contains_code(codes, CVA_CODES))
    height_cm = X["donor_height_cm"]
    weight_kg = X["donor_weight_kg"]
    # Mainly strokes and similar causes, we search in all codes
    # death codes never have these
    cause_cardiac = all_codes.apply(lambda codes: contains_code(codes, CARDIAC_DEATH_CODES))
    # This gets removed during preprocessing/feature engineering
    hcv = np.repeat(False, X.shape[0])
    hla_b_mismatch = X["hla_mismatch_broad_mis_b"]
    hla_dr_mismatch = X["hla_mismatch_broad_mis_dr"]
    cold_ischemia_hours = X["transplantation_cold_ischemia_time_min"] / 60.0
    en_bloc = (X["organ_removal_is_enbloc"] == "yes") * 1.0
    en_bloc[X["organ_removal_is_enbloc"].isna()] = np.nan
    # This gets removed during preprocessing/feature engineering
    double_kidney = np.repeat(False, X.shape[0])
    return pd.DataFrame(
        {
            "age": age,
            "african_american": african_american,
            "creatinine": creatinine,
            "hypertensive": hypertensive,
            "diabetic": diabetic,
            "cause_cva": cause_cva,
            "height_cm": height_cm,
            "weight_kg": weight_kg,
            "dcd": cause_cardiac,
            "hcv": hcv,
            "hla_b_mismatch": hla_b_mismatch,
            "hla_dr_mismatch": hla_dr_mismatch,
            "cold_ischemia_hours": cold_ischemia_hours,
            "en_bloc": en_bloc,
            "double_kidney": double_kidney,
        }
    )


def construct_raw_epts_df_names(transformer, feature_names_in):
    """Return output feature names for the raw EPTS transformer."""
    return ["age", "diabetes", "prior_transplant", "years_on_dialysis"]


def construct_raw_epts_df(X):
    """Construct the raw EPTS feature DataFrame from input X."""
    # This is done for recipients
    age = X["recipient_age"]
    # This is unavailable in TxReg data, as we have interactions
    # we assume a 10% likelihood of diabetes
    diabetes = np.repeat(0.1, X.shape[0])
    # we have no prior transplants in the current data
    prior_transplant = np.repeat(0.0, X.shape[0])
    years_on_dialysis = X["waiting_list_dialysis_years"].round(0)
    years_on_dialysis[pd.isna(years_on_dialysis)] = 0.0
    years_on_dialysis[years_on_dialysis < 0.0] = 0.0
    return pd.DataFrame(
        {
            "age": age,
            "diabetes": diabetes,
            "prior_transplant": prior_transplant,
            "years_on_dialysis": years_on_dialysis,
        }
    )


def construct_dgf_irish_df_names(transformer, feature_names_in):
    """Return output feature names for the DGF Irish transformer."""
    return [
        "recipient_black",
        "recipient_male",
        "recipient_previous_transplant",
        "recipient_diabetes",
        "recipient_peak_pra",
        "recipient_pretransplant_transfusions",
        "recipient_hla_mismatches",
        "recipient_bmi",
        "recipient_dialysis_days",
        "donor_age",
        "cold_ischemia_hours",
        "warm_ischemia_minutes",
        "donor_dcd",
        "donor_hypertension",
        "donor_creatinine_mg_dl",
        "donor_cause_anoxia",
        "donor_cause_cva",
        "donor_weight_kg",
    ]


def construct_dgf_irish_df(X):
    """Construct a DataFrame with DGF risk features for the Irish score."""
    # Recipient parameters
    # Black race is unavailable in TxReg data - assume 0
    recipient_black = np.repeat(0.0, X.shape[0])

    recipient_male = (X["recipient_sex"] == "male") * 1.0
    recipient_male[X["recipient_sex"].isna()] = np.nan

    # No prior transplants in current data
    recipient_previous_transplant = np.repeat(0.0, X.shape[0])

    # Extract diabetes from kidney base disease ICD10 codes
    kidney_disease_codes = X["waiting_list_kidney_base_disease_icd10"].str.split(";;")
    recipient_diabetes = kidney_disease_codes.apply(
        lambda codes: contains_code(codes, DIABETES_CODES)
    )

    # Peak PRA
    recipient_peak_pra = X["maxPRA"]

    # Blood transfusions
    recipient_pretransplant_transfusions = (X["recipient_bloodtransfusion"] == "yes") * 1.0
    recipient_pretransplant_transfusions[X["recipient_bloodtransfusion"].isna()] = np.nan

    # Total HLA mismatches
    recipient_hla_mismatches = (
        X["hla_mismatch_broad_mis_a"]
        + X["hla_mismatch_broad_mis_b"]
        + X["hla_mismatch_broad_mis_dr"]
    )

    # BMI calculation
    recipient_bmi = X["recipient_weight_kg"] / ((X["recipient_height_cm"] / 100) ** 2)

    # Dialysis days
    recipient_dialysis_days = X["waiting_list_dialysis_years"] * 365.25
    recipient_dialysis_days[pd.isna(recipient_dialysis_days)] = 0.0
    recipient_dialysis_days[recipient_dialysis_days < 0.0] = 0.0

    # Donor parameters
    donor_age = X["donor_age"]

    cold_ischemia_hours = X["transplantation_cold_ischemia_time_min"] / 60.0

    warm_ischemia_minutes = X["transplantation_warm_ischemia_time_min"]

    # DCD - donation after cardiac death (use cardiac death codes)
    # Mainly strokes and similar causes, we search in all codes
    # death codes never have these
    all_donor_codes = X["donor_diagnosis_icd10"].str.split(";;")
    donor_dcd = all_donor_codes.apply(lambda codes: contains_code(codes, CARDIAC_DEATH_CODES))

    donor_hypertension = (X["donor_hypertension"] == "yes") * 1.0
    donor_hypertension[X["donor_hypertension"].isna()] = np.nan

    # Convert creatinine from umol/L to mg/dL
    donor_creatinine_mg_dl = X["donor_chem_creatinine_umol_per_l"] / 88.4

    # Anoxia as cause of death - need to define anoxia codes
    donor_cause_anoxia = all_donor_codes.apply(lambda codes: contains_code(codes, ANOXIA_CODES))

    # CVA as cause of death
    donor_cause_cva = all_donor_codes.apply(lambda codes: contains_code(codes, CVA_CODES))

    donor_weight_kg = X["donor_weight_kg"]

    return pd.DataFrame(
        {
            "recipient_black": recipient_black,
            "recipient_male": recipient_male,
            "recipient_previous_transplant": recipient_previous_transplant,
            "recipient_diabetes": recipient_diabetes,
            "recipient_peak_pra": recipient_peak_pra,
            "recipient_pretransplant_transfusions": recipient_pretransplant_transfusions,
            "recipient_hla_mismatches": recipient_hla_mismatches,
            "recipient_bmi": recipient_bmi,
            "recipient_dialysis_days": recipient_dialysis_days,
            "donor_age": donor_age,
            "cold_ischemia_hours": cold_ischemia_hours,
            "warm_ischemia_minutes": warm_ischemia_minutes,
            "donor_dcd": donor_dcd,
            "donor_hypertension": donor_hypertension,
            "donor_creatinine_mg_dl": donor_creatinine_mg_dl,
            "donor_cause_anoxia": donor_cause_anoxia,
            "donor_cause_cva": donor_cause_cva,
            "donor_weight_kg": donor_weight_kg,
        }
    )


def apply_kdri_transform(X):
    """Apply the KDRI score transformation to a DataFrame-like input."""
    return kdri(
        age=X["age"],
        african_american=X["african_american"],
        creatinine=X["creatinine"],
        hypertensive=X["hypertensive"],
        diabetic=X["diabetic"],
        cause_cva=X["cause_cva"],
        height_cm=X["height_cm"],
        weight_kg=X["weight_kg"],
        dcd=X["dcd"],
        hcv=X["hcv"],
        hla_b_mismatch=X["hla_b_mismatch"],
        hla_dr_mismatch=X["hla_dr_mismatch"],
        cold_ischemia_hours=X["cold_ischemia_hours"],
        en_bloc=X["en_bloc"],
        double_kidney=X["double_kidney"],
    )


def apply_raw_epts_transform(X):
    """Apply the raw EPTS score transformation to a DataFrame-like input."""
    return raw_epts(
        age=X["age"],
        diabetes=X["diabetes"],
        prior_transplant=X["prior_transplant"],
        years_on_dialysis=X["years_on_dialysis"],
    )


def apply_dgf_risk_irish_transform(X):
    """Apply the DGF Irish risk transformation to a DataFrame-like input."""
    return dgf_risk_irish(
        recipient_black=X["recipient_black"],
        recipient_male=X["recipient_male"],
        recipient_previous_transplant=X["recipient_previous_transplant"],
        recipient_diabetes=X["recipient_diabetes"],
        deltamax_pra=X["deltamax_pra"],
        recipient_pretransplant_transfusions=X["recipient_pretransplant_transfusions"],
        recipient_hla_mismatches=X["recipient_hla_mismatches"],
        recipient_bmi=X["recipient_bmi"],
        recipient_dialysis_days=X["recipient_dialysis_days"],
        donor_age=X["donor_age"],
        cold_ischemia_hours=X["cold_ischemia_hours"],
        warm_ischemia_minutes=X["warm_ischemia_minutes"],
        donor_dcd=X["donor_dcd"],
        donor_hypertension=X["donor_hypertension"],
        donor_creatinine_mg_dl=X["donor_creatinine_mg_dl"],
        donor_cause_anoxia=X["donor_cause_anoxia"],
        donor_cause_cva=X["donor_cause_cva"],
        donor_weight_kg=X["donor_weight_kg"],
    )


def name_returner(transformer, feature_names_in, scorename):
    """Return a single-element list containing the score name.

    Used as a `feature_names_out` helper for transformers.
    """
    return [scorename]


def prep_def(trial, seed):
    """Prepare and return the needed feature set and transformers for scoring.

    Returns transformer definitions and the set of features required.
    """
    needed_features = {
        # KDRI features
        "donor_age",
        "donor_chem_creatinine_umol_per_l",
        "donor_hypertension",
        "donor_diagnosis_icd10",
        "donor_height_cm",
        "donor_weight_kg",
        "transplantation_cold_ischemia_time_min",
        "organ_removal_is_enbloc",
        "hla_mismatch_broad_mis_b",
        "hla_mismatch_broad_mis_dr",
        # Raw EPTS features
        "recipient_age",
        "waiting_list_dialysis_years",
        # DGF Risk Irish features
        "recipient_sex",
        "waiting_list_kidney_base_disease_icd10",
        "deltamax_pra",
        "recipient_bloodtransfusion",
        "hla_mismatch_broad_mis_a",
        "recipient_weight_kg",
        "recipient_height_cm",
        "transplantation_warm_ischemia_time_min",
    }

    kdri_feat_transformer = FunctionTransformer(
        construct_kdri_df, validate=False, feature_names_out=construct_kdri_df_names
    )
    kdri_transformer = FunctionTransformer(
        apply_kdri_transform,
        validate=False,
        feature_names_out=partial(name_returner, scorename="kdri"),
    )

    kdri_pipeline = make_pipeline(kdri_feat_transformer, SimpleImputer(), kdri_transformer)

    raw_epts_feat_transformer = FunctionTransformer(
        construct_raw_epts_df,
        validate=False,
        feature_names_out=construct_raw_epts_df_names,
    )
    raw_epts_transformer = FunctionTransformer(
        apply_raw_epts_transform,
        validate=False,
        feature_names_out=partial(name_returner, scorename="raw_epts"),
    )
    raw_epts_pipeline = make_pipeline(
        raw_epts_feat_transformer, SimpleImputer(), raw_epts_transformer
    )

    dgf_risk_irish_feat_transformer = FunctionTransformer(
        construct_dgf_irish_df,
        validate=False,
        feature_names_out=construct_dgf_irish_df_names,
    )
    dgf_risk_irish_transformer = FunctionTransformer(
        apply_dgf_risk_irish_transform,
        validate=False,
        feature_names_out=partial(name_returner, scorename="dgf_risk"),
    )
    dgf_risk_irish_pipeline = make_pipeline(
        dgf_risk_irish_feat_transformer, SimpleImputer(), dgf_risk_irish_transformer
    )

    steps = [
        (
            "fu",
            FeatureUnion(
                [
                    ("kdri", kdri_pipeline),
                    ("raw_epts", raw_epts_pipeline),
                    ("dgf_risk_irish", dgf_risk_irish_pipeline),
                ],
                verbose_feature_names_out=False,
            ),
        )
    ]

    steps.append(("scaler", StandardScaler()))

    pipe = Pipeline(steps)

    return pipe, needed_features
