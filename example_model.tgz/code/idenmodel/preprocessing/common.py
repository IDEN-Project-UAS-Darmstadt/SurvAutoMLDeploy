"""Common preprocessing helpers and survival summary utilities."""

import base64
import hashlib
import os
import re
import tempfile

import mlflow
import numpy as np
import pandas as pd
from pandas.util import hash_pandas_object  # pylint: disable=no-name-in-module
from sksurv.nonparametric import _compute_counts, kaplan_meier_estimator
from sksurv.util import check_y_survival


def calculate_hash(X, firstchars=16):
    """Return a stable short hash for the contents of a DataFrame."""
    with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
        tmp_path = tmp.name
        X.to_csv(tmp_path, index=False)
    X_read = pd.read_csv(tmp_path)
    os.remove(tmp_path)
    combined = hashlib.sha256()
    hashes = hash_pandas_object(X_read, index=False)
    for i in range(len(hashes)):
        combined.update(hashes.iloc[i])
    res = base64.b64encode(combined.digest())
    if firstchars is not None:
        res = res[:firstchars]
    return res.decode("utf-8")


def log_data(df, context):
    """Log a DataFrame as an MLflow input with a content-derived digest."""
    digest = calculate_hash(df)
    dataset = mlflow.data.from_pandas(df, digest=digest)  # pylint: disable=no-member
    mlflow.log_input(dataset, context=context)
    return dataset


def convert_numeric_to_float(df):
    """Convert all numeric columns in a DataFrame to float64."""
    sel = df.select_dtypes(np.number)
    df[sel.columns] = sel.astype("float64")
    return df


def extended_km(event, time_exit):
    """Compute an extended Kaplan-Meier summary table."""
    km_time, km_surv, km_conf_int = kaplan_meier_estimator(
        event, time_exit, conf_type="log-log", conf_level=0.95
    )
    event, _, time_exit = check_y_survival(event, None, time_exit, allow_all_censored=True)
    uniq_times, n_events, n_at_risk, n_censored = _compute_counts(event, time_exit)
    assert np.all(uniq_times == km_time)
    return pd.DataFrame(
        {
            "time": km_time,
            "surv": km_surv,
            "conf_lower": km_conf_int[0],
            "conf_upper": km_conf_int[1],
            "n_at_risk": n_at_risk,
        }
    )


def icd_10_cleaning(codes):
    """Clean ICD-10 codes by stripping whitespace and trailing punctuation."""
    is_array = hasattr(codes, "__len__") and not isinstance(codes, str)
    if not is_array and pd.isna(codes):
        return pd.NA
    code_series = pd.Series(codes) if is_array else pd.Series([codes])
    code_series = code_series.str.strip()
    code_series = code_series.str.replace(r"!+$", "", regex=True)
    code_series = code_series.str.replace(r"\*+$", "", regex=True)

    code_series = code_series.str.replace(r"\.\-+$", "", regex=True)

    code_series = code_series.str.replace(r"[.\-]+$", "", regex=True)

    return code_series.to_list() if is_array else code_series.iloc[0]


def find_icd10_columns(df: pd.DataFrame) -> list:
    """Identify columns in the DataFrame that likely contain ICD10 codes based on their names."""
    candidates = df.select_dtypes(include="object").columns
    return candidates[candidates.str.contains(r"icd", flags=re.IGNORECASE)].to_list()
