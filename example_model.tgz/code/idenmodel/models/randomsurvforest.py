"""Random Survival Forest wrapper using scikit-survival package."""

import mlflow
from sklearn import set_config
from sklearn.pipeline import Pipeline
from sksurv.ensemble import RandomSurvivalForest

from .common import prep_def_choose

set_config(transform_output="pandas")


def model_def(trial, seed):
    """Build the RandomSurvivalForest pipeline for Optuna search."""
    n_estimators = trial.suggest_int("n_estimators", 50, 800, step=50)
    min_samples_leaf = trial.suggest_int(
        "min_samples_leaf", 10, 50
    )  # Increased min from 3 to reduce overfitting
    min_samples_split = trial.suggest_int(
        "min_samples_split", 20, 100
    )  # Increased min/max for stability
    max_depth = trial.suggest_int("max_depth", 10, 25)  # Reduced max from 30 to prevent overfitting
    model = RandomSurvivalForest(
        random_state=seed,
        n_estimators=n_estimators,
        min_samples_leaf=min_samples_leaf,
        min_samples_split=min_samples_split,
        max_depth=max_depth,
        verbose=10,
    )
    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params(
        {
            "n_estimators": n_estimators,
            "min_samples_leaf": min_samples_leaf,
            "min_samples_split": min_samples_split,
        }
    )
    mlflow.set_tag("modeltype", "Random Survival Forest")
    return pipe, needed_features
