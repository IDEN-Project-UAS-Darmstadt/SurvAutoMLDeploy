"""IPCW Logistic Regression model definition for survival analysis."""

import mlflow
from sklearn import set_config
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from .common import IPCWModel, prep_def_choose

set_config(transform_output="pandas")


def model_def(trial, seed):
    """Define the IPCW Logistic Regression model with optional L2 regularization."""
    use_alpha = trial.suggest_categorical("use_alpha", [True, False])
    if use_alpha:
        alpha = trial.suggest_float("alpha", 1e-5, 0.1, log=True)
    else:
        alpha = 1
    model = LogisticRegression(l1_ratio=0, C=1 / alpha, random_state=seed)
    # taus is being set during training
    model = IPCWModel(base_model=model, taus=[])
    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params({"alpha": alpha, "use_alpha": use_alpha})
    mlflow.set_tag("modeltype", "IPCW Logistic Regression")

    return pipe, needed_features
