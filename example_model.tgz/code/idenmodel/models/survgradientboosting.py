"""Gradient boosting survival model definition."""

import mlflow
from sklearn import set_config
from sklearn.pipeline import Pipeline
from sksurv.ensemble import GradientBoostingSurvivalAnalysis

from .common import prep_def_choose

set_config(transform_output="pandas")


def model_def(trial, seed):
    """Build the gradient boosting survival pipeline for Optuna search."""
    n_estimators = trial.suggest_int("n_estimators", 100, 800, step=50)
    min_samples_leaf = trial.suggest_int("min_samples_leaf", 10, 50)
    min_samples_split = trial.suggest_int("min_samples_split", 20, 100)
    learning_rate = trial.suggest_float("learning_rate", 0.005, 0.1, log=True)
    subsample = trial.suggest_float("subsample", 0.7, 1.0)
    max_depth = trial.suggest_int("max_depth", 1, 5)

    model = GradientBoostingSurvivalAnalysis(
        n_estimators=n_estimators,
        min_samples_leaf=min_samples_leaf,
        min_samples_split=min_samples_split,
        learning_rate=learning_rate,
        tol=1e-4,
        max_depth=max_depth,
        subsample=subsample,
        verbose=10,
        validation_fraction=0.2,
        n_iter_no_change=20,
        random_state=seed,
    )
    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params(
        {
            "n_estimators": n_estimators,
            "min_samples_leaf": min_samples_leaf,
            "min_samples_split": min_samples_split,
            "learning_rate": learning_rate,
            "max_depth": max_depth,
            "subsample": subsample,
        }
    )
    mlflow.set_tag("modeltype", "Gradient Boosting Survival")

    return pipe, needed_features
