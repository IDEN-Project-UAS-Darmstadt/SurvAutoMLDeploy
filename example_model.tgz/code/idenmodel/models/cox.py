"""Cox Proportional Hazards model definition for survival analysis."""

import mlflow
from sklearn import set_config
from sklearn.pipeline import Pipeline
from sksurv.linear_model import CoxPHSurvivalAnalysis

from .common import prep_def_choose

set_config(transform_output="pandas")


def model_def(trial, seed):
    """Define the Cox Proportional Hazards model with optional L2 regularization."""
    use_alpha = trial.suggest_categorical("use_alpha", [True, False])
    if use_alpha:
        alpha = trial.suggest_float("alpha", 1e-5, 0.1, log=True)
    else:
        alpha = 0
    model = CoxPHSurvivalAnalysis(alpha=alpha)
    pipe, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", pipe), ("model", model)])

    mlflow.log_params({"use_alpha": use_alpha, "alpha": alpha})
    mlflow.set_tag("modeltype", "Cox Regression")

    return pipe, needed_features
