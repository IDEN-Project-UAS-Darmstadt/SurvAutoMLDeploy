"""IPCW Random Forest model definition and Optuna config.

Provides a wrapper that builds an IPCW-wrapped RandomForestClassifier
and logs hyperparameters to MLflow.
"""

import mlflow
from sklearn import set_config
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline

from .common import IPCWModel, prep_def_choose

set_config(transform_output="pandas")


def model_def(trial, seed):
    """Define the Optuna search space and return a pipeline.

    Args:
        trial: Optuna trial object.
        seed: Random seed for reproducibility.

    Returns:
        tuple: `(Pipeline, needed_features)` for training.
    """
    taus = []

    n_estimators = trial.suggest_int("n_estimators", 100, 2000, step=100)
    min_samples_leaf = trial.suggest_int("min_samples_leaf", 3, 50, log=True)
    min_samples_split = trial.suggest_int("min_samples_split", 6, 150, log=True)

    model = IPCWModel(
        base_model=RandomForestClassifier(
            random_state=seed,
            n_estimators=n_estimators,
            min_samples_leaf=min_samples_leaf,
            min_samples_split=min_samples_split,
            verbose=10,
        ),
        taus=taus,
    )
    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params(
        {
            "n_estimators": n_estimators,
            "min_samples_leaf": min_samples_leaf,
            "min_samples_split": min_samples_split,
        }
    )
    mlflow.set_tag("modeltype", "IPCW Random Forest")

    return pipe, needed_features
