"""Random Survival Forest wrapper via the R ranger package."""

from numbers import Integral

import mlflow
import numpy as np
import rpy2.robjects as ro
from rpy2.robjects import numpy2ri
from rpy2.robjects.packages import importr
from sklearn import set_config
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.utils._param_validation import Interval
from sklearn.utils.validation import check_is_fitted, validate_data
from sksurv.base import SurvivalAnalysisMixin
from sksurv.tree._criterion import get_unique_times  # pylint: disable=no-name-in-module
from sksurv.tree.tree import _array_to_step_function
from sksurv.util import check_array_survival

from .common import prep_def_choose

survival = importr("survival")
stats = importr("stats")
survmetrics = importr("SurvMetrics")
base = importr("base")
ranger = importr("ranger")
utils = importr("utils")

set_config(transform_output="pandas")


class Ranger(BaseEstimator, SurvivalAnalysisMixin):
    """A sklearn-compatible random forest wrapping R's ranger package."""

    _parameter_constraints = {
        #  "dist": [StrOptions({"lognormal","loglogistic","weibull"})],
        #  "scale": [Interval(Real, None, None, closed="both")],
        "n_estimators": [Interval(Integral, 1, None, closed="left")],
        "n_jobs": [Integral],
        "min_node_size": [Interval(Integral, 1, None, closed="left")],
        "min_bucket": [Interval(Integral, 1, None, closed="left")],
        "max_depth": [Interval(Integral, 1, None, closed="left"), None],
        "taus": ["array-like", None],
        "seed": [Integral, None],
    }

    def __init__(
        self,
        *,
        n_estimators=500,
        n_jobs=-1,
        min_node_size=3,
        min_bucket=1,
        max_depth=None,
        taus=None,
        seed=None,
    ):
        """Store the ranger hyperparameters for survival modeling."""
        self.n_estimators = n_estimators
        self.n_jobs = n_jobs
        self.min_node_size = min_node_size
        self.min_bucket = min_bucket
        self.max_depth = max_depth
        self.taus = taus
        self.seed = seed

    def _check_params(self):
        """Validate estimator parameters against sklearn constraints."""
        self._validate_params()

    @property
    def _predict_risk_score(self):
        """Indicate that the model returns risk scores (not negative risk)."""
        return True

    def fit(self, X, y):
        """Fit the ranger model via R on the provided survival data."""
        # Use sklearn.utils.validation.validate_data introduced in newer versions
        # to validate inputs similarly to the previous _validate_data.
        X, y = validate_data(
            self,
            X=X,
            y=y,
            reset=True,
            validate_separately=False,
            ensure_min_samples=2,
            dtype=np.float64,
        )
        self._check_params()
        event, time = check_array_survival(X, y)
        self.unique_times_ = get_unique_times(time, event)[0]
        # ex. 0 -> 1
        self.time_shift_ = 1 - np.min(self.unique_times_)
        with ro.local_context() as lc:
            # ro.default_converter +
            with (numpy2ri.converter).context():
                lc["X"] = ro.conversion.get_conversion().py2rpy(X)
                lc["time"] = time + self.time_shift_
                lc["event"] = event * 1
                lc["num.tree"] = self.n_estimators
                lc["num.threads"] = self.n_jobs
                lc["max.depth"] = self.max_depth
                lc["seed"] = self.seed
                if self.n_jobs <= 0:
                    lc["num.threads"] = 0
                if self.taus is not None:
                    lc["time.interest"] = ro.conversion.get_conversion().py2rpy(
                        self.taus + self.time_shift_
                    )
                else:
                    lc["time.interest"] = ro.conversion.get_conversion().py2rpy(
                        self.unique_times_ + self.time_shift_
                    )
                lc["min.node.size"] = self.min_node_size
                lc["min.bucket"] = self.min_bucket
            formula = (
                "ranger::ranger("
                "Surv(time, event) ~ ., seed=seed, data=as.data.frame(X), "
                "num.trees=num.tree, num.threads=num.threads, "
                "min.node.size=min.node.size, min.bucket=min.bucket, "
                "max.depth=max.depth, "
                "oob.error=FALSE, time.interest=time.interest)"
            )
            self.model_ = ro.r(formula)
        return self

    def predict(self, X, check_input=True):
        """Predict risk scores by cumulative hazard over all times."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
        # matrix of shape (n_samples, n_times)
        res = ranger.predict_ranger(self.model_, data=base.as_data_frame(X_r), type="response").rx2(
            "chf"
        )
        # Ensure res is always 2D (n_samples, n_times)
        res = np.array(res)
        if res.ndim == 1:
            res = res.reshape(1, -1)
        # sum over time to get risk score
        res = np.sum(res, axis=1)
        return np.array(res)

    def predict_cumulative_hazard_function(self, X, check_input=True, return_array=False):
        """Predict cumulative hazard functions for each row in X."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
        res = ranger.predict_ranger(self.model_, data=base.as_data_frame(X_r), type="response")
        times = np.array(res.rx2("unique.death.times")) - self.time_shift_
        res = np.array(res.rx2("chf"))
        # Ensure res is always 2D (n_samples, n_times)
        if res.ndim == 1:
            res = res.reshape(1, -1)
        if return_array:
            return res
        return _array_to_step_function(times, res)

    def predict_survival_function(self, X, check_input=True, return_array=False):
        """Predict survival functions for each row in X."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
        res = ranger.predict_ranger(self.model_, data=base.as_data_frame(X_r), type="response")
        times = np.array(res.rx2("unique.death.times")) - self.time_shift_
        res = np.array(res.rx2("survival"))
        # Ensure res is always 2D (n_samples, n_times)
        if res.ndim == 1:
            res = res.reshape(1, -1)
        if return_array:
            return res
        return _array_to_step_function(times, res)


def model_def(trial, seed):
    """Build the ranger survival forest pipeline for Optuna search."""
    # dist = trial.suggest_categorical("dist", ["lognormal","loglogistic","weibull"])
    n_estimators = trial.suggest_int("n_estimators", 50, 800, step=50)
    min_samples_leaf = trial.suggest_int(
        "min_samples_leaf", 10, 50
    )  # Increased min from 3 to reduce overfitting
    min_samples_split = trial.suggest_int(
        "min_samples_split", 20, 100
    )  # Increased min/max for stability
    max_depth = trial.suggest_int("max_depth", 10, 25)

    model = Ranger(
        n_estimators=n_estimators,
        seed=seed,
        n_jobs=-1,
        min_node_size=min_samples_split,
        min_bucket=min_samples_leaf,
        max_depth=max_depth,
    )

    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params(
        {
            "n_estimators": n_estimators,
            "min_samples_leaf": min_samples_leaf,
            "min_samples_split": min_samples_split,
            "max_depth": max_depth,
        }
    )
    mlflow.set_tag("modeltype", "Random Survival Forest - Ranger")

    return pipe, needed_features
