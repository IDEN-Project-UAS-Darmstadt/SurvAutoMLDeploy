"""Parametric survival regression model definitions."""

from numbers import Real

import mlflow
import numpy as np
import rpy2.robjects as ro
from rpy2.robjects import numpy2ri
from rpy2.robjects.packages import importr
from sklearn import set_config
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.utils._param_validation import Interval, StrOptions
from sklearn.utils.validation import check_is_fitted, validate_data
from sksurv.base import SurvivalAnalysisMixin
from sksurv.tree._criterion import get_unique_times  # pylint: disable=no-name-in-module
from sksurv.tree.tree import _array_to_step_function
from sksurv.util import check_array_survival

from .common import prep_def_choose

survival = importr("survival")
stats = importr("stats")
survmetrics = importr("SurvMetrics")
base = importr("base")

set_config(transform_output="pandas")


class SurvReg(BaseEstimator, SurvivalAnalysisMixin):
    """A parametric survival regression wrapper around R's survreg."""

    _parameter_constraints = {
        "dist": [StrOptions({"lognormal", "loglogistic", "weibull"})],
        "scale": [Interval(Real, None, None, closed="both")],
    }

    def __init__(self, *, dist="weibull", scale=0):
        """Store distribution and scale parameters."""
        self.dist = dist
        self.scale = scale

    def _check_params(self):
        """Validate estimator parameters against sklearn constraints."""
        self._validate_params()

    def fit(self, X, y):
        """Fit the survival regression model on feature matrix X and y."""
        X, y = validate_data(
            self,
            X=X,
            y=y,
            reset=True,
            validate_separately=False,
            ensure_min_samples=2,
            dtype=np.float64,
        )
        self._check_params()
        event, time = check_array_survival(X, y)
        self.unique_times_ = get_unique_times(time, event)[0]
        # ex. 0 -> 1
        self.time_shift_ = 1 - np.min(self.unique_times_)
        with ro.local_context() as lc:
            # ro.default_converter +
            with (numpy2ri.converter).context():
                lc["X"] = ro.conversion.get_conversion().py2rpy(X)
                lc["time"] = time + self.time_shift_
                lc["event"] = event * 1
                lc["dist"] = self.dist
                lc["scale"] = self.scale
            self.model_ = ro.r(
                "survival::survreg("
                "Surv(time, event) ~ ., data=as.data.frame(X), "
                "dist=dist, scale=scale)"
            )
        return self

    @property
    def _predict_risk_score(self):
        """Indicate that higher predicted values mean lower risk."""
        return False

    def predict(self, X, check_input=True):
        """Predict survival times for the provided feature matrix."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
        res = survival.predict_survreg(
            self.model_, newdata=base.as_data_frame(X_r), type="response"
        )
        return np.array(res)

    def predict_cumulative_hazard_function(self, X, check_input=True, return_array=False):
        """Predict cumulative hazard functions for each row in X."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
            times_r = ro.conversion.get_conversion().py2rpy(self.unique_times_ + self.time_shift_)
        res = base.log(
            survmetrics.predictSurvProb_survreg(self.model_, base.as_data_frame(X_r), times_r)
        )
        res = -np.array(res)
        if return_array:
            return res
        return _array_to_step_function(self.unique_times_, res)

    def predict_survival_function(self, X, check_input=True, return_array=False):
        """Predict survival functions for each row in X."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
            times_r = ro.conversion.get_conversion().py2rpy(self.unique_times_ + self.time_shift_)
        res = survmetrics.predictSurvProb_survreg(self.model_, base.as_data_frame(X_r), times_r)
        res = np.array(res)
        if return_array:
            return res
        return _array_to_step_function(self.unique_times_, res)


def model_def(trial, seed):
    """Build the survival regression pipeline for Optuna search."""
    dist = trial.suggest_categorical("dist", ["lognormal", "loglogistic", "weibull"])
    # This estimates the scale automatically
    scale = 0
    model = SurvReg(dist=dist, scale=scale)
    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params({"dist": dist, "scale": scale})
    mlflow.set_tag("modeltype", "AFT")

    return pipe, needed_features
