"""Simplified survival models used as sklearn estimators.

Contains a trivial selector (`NothingSelector`) used to satisfy the
pipeline API and a Kaplan-Meier based model (`KMModel`) exposing the
methods expected by the training/evaluation code.
"""

import mlflow
import numpy as np
from sklearn import set_config
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.utils.validation import _check_feature_names, check_is_fitted
from sksurv.nonparametric import SurvivalFunctionEstimator
from sksurv.tree.tree import _array_to_step_function

set_config(transform_output="pandas")


class NothingSelector(BaseEstimator):
    """A passthrough-like transformer that returns a single zero column.

    Used as a placeholder transformer so pipelines have a `prep` step.
    """

    def __init__(self):
        """Initialize the selector (no parameters)."""

    def fit(self, X, y=None):
        """Record feature names and return self.

        This validates input feature names for compatibility with sklearn
        transform checks.
        """
        _check_feature_names(self, X, reset=True)
        return self

    def transform(self, X):
        """Return a single zero column matching the number of rows in X."""
        _check_feature_names(self, X, reset=False)
        allzerosinglefeature = np.zeros((X.shape[0], 1))
        return allzerosinglefeature

    def get_feature_names_out(self, input_features=None):
        """Return a single feature name for the produced column."""
        check_is_fitted(self)
        return np.array(["empty"])


class KMModel(BaseEstimator):
    """A Kaplan-Meier based model exposing sklearn-like predict methods.

    The model stores a fitted `sksurv` SurvivalFunctionEstimator and
    exposes `predict`, `predict_survival_function` and
    `predict_cumulative_hazard_function` for compatibility with the
    evaluation code.
    """

    def __init__(self):
        """Initialize the KMModel (no hyperparameters)."""

    @property
    def unique_times_(self):
        """Return the unique event times learned from the fitted estimator.

        The first entry of the underlying `sksurv` object is -Inf and thus
        is skipped here.
        """
        return self.km_model_.unique_time_[1:]

    def fit(self, X, y):
        """Fit the KM estimator on the provided survival data `y`.

        The input `X` is ignored because KM is a global estimator.
        """
        km = SurvivalFunctionEstimator()
        self.km_model_ = km.fit(y)
        return self

    def predict(self, X):
        """Return a constant risk score for all rows (KM is agnostic).

        The training/evaluation pipeline expects a numeric risk score.
        """
        check_is_fitted(self, "km_model_")
        # All have the same risk
        return np.ones(X.shape[0], dtype="float")

    def predict_cumulative_hazard_function(self, X, return_array=False):
        """Return the cumulative hazard function for each row in X.

        If `return_array` is True, a 2D numpy array is returned where each
        row corresponds to an observation and columns to times. Otherwise
        a step-function object is returned as used elsewhere in the repo.
        """
        check_is_fitted(self, "km_model_")
        arr = self.km_model_.predict_proba(self.unique_times_)
        arr = -np.log(arr)
        arr = np.tile(arr, (X.shape[0], 1))
        if return_array:
            return arr
        return _array_to_step_function(self.unique_times_, arr)

    def predict_survival_function(self, X, return_array=False):
        """Return the survival function for each row in X.

        See `predict_cumulative_hazard_function` for return value details.
        """
        check_is_fitted(self, "km_model_")
        arr = self.km_model_.predict_proba(self.unique_times_)
        arr = np.tile(arr, (X.shape[0], 1))
        if return_array:
            return arr
        return _array_to_step_function(self.unique_times_, arr)


def model_def(trial, seed):
    """Return a pipeline that uses the KMModel as a placeholder model.

    The function is intentionally simple and exists so the training
    pipeline can run experiments without a fitted covariate model.
    """
    model = KMModel()
    pipe = Pipeline([("prep", NothingSelector()), ("model", model)])
    trial.suggest_categorical("nothing", ["nothing"])
    mlflow.set_tag("modeltype", "Kaplan-Meier")

    # This is just as a placeholder for compatibility
    return pipe, ["recipient_age"]
