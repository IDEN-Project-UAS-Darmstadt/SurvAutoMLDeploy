"""DeepSurv survival model implementation.

This module provides a DeepSurv model for survival analysis, wrapping the pycox library
with scikit-learn and scikit-survival compatibility.
"""

import numbers

import mlflow
import numpy as np
import plotly.express as px
import torch
import torchtuples as tt
from pycox.models import CoxPH
from sklearn import set_config
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.utils._param_validation import Integral, Interval
from sklearn.utils.validation import check_is_fitted, validate_data
from sksurv.base import SurvivalAnalysisMixin
from sksurv.tree.tree import _array_to_step_function
from sksurv.util import check_array_survival

from idenmodel.models.common import prep_def_choose

from ..common import setup_logging

set_config(transform_output="pandas")

logger = setup_logging("DeepSurv")


class DeepSurv(BaseEstimator, SurvivalAnalysisMixin):
    """DeepSurv model for survival analysis.

    Implements a deep learning-based Cox regression model using neural networks,
    compatible with scikit-learn and scikit-survival interfaces.
    """

    _parameter_constraints = {
        "num_nodes": ["array-like"],
        "dropout": [Interval(numbers.Real, 0, 1, closed="both")],
        "batch_norm": [bool],
        "epochs": [Interval(Integral, 1, None, closed="left")],
        "batch_size": [Interval(Integral, 1, None, closed="left")],
        "val_fraction": [Interval(numbers.Real, 0, 1, closed="both")],
        "seed": [Integral, None],
        "mlflow_logging": [bool],
    }

    def __init__(
        self,
        *,
        num_nodes,
        dropout,
        batch_norm,
        epochs,
        batch_size=256,
        val_fraction=0.1,
        seed=None,
        mlflow_logging=False,
    ):
        """Initialize DeepSurv model.

        Parameters
        ----------
        num_nodes : list of int
            Number of nodes in each layer.
        dropout : float
            Dropout rate.
        batch_norm : bool
            Whether to use batch normalization.
        epochs : int
            Number of training epochs.
        batch_size : int, default=256
            Batch size for training.
        val_fraction : float, default=0.1
            Fraction of data to use for validation.
        seed : int, optional
            Random seed for reproducibility.
        mlflow_logging : bool, default=False
            Whether to log metrics to MLflow.
        """
        self.num_nodes = num_nodes
        self.dropout = dropout
        self.batch_norm = batch_norm
        self.epochs = epochs
        self.seed = seed
        self.val_fraction = val_fraction
        self.batch_size = batch_size
        self.mlflow_logging = mlflow_logging

    def _check_params(self):
        """Validate hyperparameters according to constraints."""
        self._validate_params()

    @property
    def _predict_risk_score(self):
        return True

    def fit(self, X, y):
        """Fit the DeepSurv model.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Training data.
        y : structured array with fields 'event' and 'time'
            Target with event indicator and survival time.

        Returns
        -------
        self : DeepSurv
            Fitted estimator.
        """
        # Use sklearn.utils.validation.validate_data introduced in newer versions
        # to validate inputs similarly to the previous _validate_data.
        X, y = validate_data(
            self,
            X=X,
            y=y,
            reset=True,
            validate_separately=False,
            ensure_min_samples=2,
            dtype=np.float32,
        )
        self._check_params()
        event, time = check_array_survival(X, y)
        event = event.astype(np.float32)
        time = time.astype(np.float32)
        np.random.seed(self.seed)
        _ = torch.manual_seed(self.seed)
        # Validation indices
        n_samples = X.shape[0]
        if self.val_fraction > 0:
            n_val = int(n_samples * self.val_fraction)
            indices = np.random.permutation(n_samples)
            val_indices = indices[:n_val]
            train_indices = indices[n_val:]
            X_val, time_val, event_val = (
                X[val_indices],
                time[val_indices],
                event[val_indices],
            )
            X, time_train, event_train = (
                X[train_indices],
                time[train_indices],
                event[train_indices],
            )
            train = (time_train, event_train)
            val = (time_val, event_val)
            val = (X_val, val)
        else:
            train = (time, event)
        in_features = X.shape[1]
        # 1 output for the cph model
        net = tt.practical.MLPVanilla(
            in_features,
            self.num_nodes,
            1,
            self.batch_norm,
            self.dropout,
            output_bias=False,
        )
        self.model_ = CoxPH(net, tt.optim.Adam)
        lr_finder = self.model_.lr_finder(X, train, batch_size=self.batch_size, tolerance=10)
        best_lr = lr_finder.get_best_lr()
        # Decrease it by 2x
        best_lr = best_lr / 2
        if self.mlflow_logging:
            mlflow.log_metric("best_lr", best_lr)
            df = lr_finder.to_pandas(smoothed=0.9).reset_index()
            fig = px.line(
                df,
                x="lr",
                y="train_loss",
                log_x=True,
                labels={"lr": "Learning rate", "train_loss": "Training loss"},
                title="LR finder",
            )
            mlflow.log_figure(fig, "lr_finder.html")
            mlflow.log_table(df, "lr_finder.json")
        self.model_.optimizer.set_lr(best_lr)
        callbacks = []
        if self.val_fraction > 0:
            callbacks.append(tt.callbacks.EarlyStopping(patience=10))
            log = self.model_.fit(
                X,
                train,
                batch_size=self.batch_size,
                epochs=self.epochs,
                callbacks=callbacks,
                verbose=True,
                val_data=val,
                val_batch_size=self.batch_size,
            )
        else:
            log = self.model_.fit(
                X,
                train,
                batch_size=self.batch_size,
                epochs=self.epochs,
                callbacks=callbacks,
                verbose=True,
            )
        if self.mlflow_logging:
            df = log.to_pandas().reset_index()
            # will have always index, and train_loss, but val_loss only if validation was used
            fig = px.line(
                df,
                x="index",
                y=(["train_loss", "val_loss"] if "val_loss" in df.columns else ["train_loss"]),
                labels={"index": "Epoch", "value": "Loss", "variable": "Loss type"},
                title="Training loss",
            )
            mlflow.log_figure(fig, "training_log.html")
            mlflow.log_table(df, "training_log.json")
        self.model_.compute_baseline_hazards()
        return self

    def predict(self, X, check_input=True):
        """Predict risk scores.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Test data.
        check_input : bool, default=True
            Whether to validate input.

        Returns
        -------
        scores : ndarray of shape (n_samples,)
            Predicted risk scores.
        """
        check_is_fitted(self, "model_")
        X = validate_data(
            self,
            X=X,
            reset=False,
            validate_separately=False,
            dtype=np.float32,
        )
        scores = self.model_.predict(X)
        # Squeeze to 1D array to match expected output shape
        return np.asarray(scores).ravel()

    def predict_cumulative_hazard_function(self, X, check_input=True, return_array=False):
        """Predict cumulative hazard function.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Test data.
        check_input : bool, default=True
            Whether to validate input.
        return_array : bool, default=False
            Whether to return as array or step function.

        Returns
        -------
        chf : ndarray or StepFunction
            Cumulative hazard function.
        """
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float32,
            )
        chf_df = self.model_.predict_cumulative_hazards(X)
        res = chf_df.values.T
        times = chf_df.index.values
        if return_array:
            return res
        return _array_to_step_function(times, res)

    def predict_survival_function(self, X, check_input=True, return_array=False):
        """Predict survival function.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Test data.
        check_input : bool, default=True
            Whether to validate input.
        return_array : bool, default=False
            Whether to return as array or step function.

        Returns
        -------
        surv : ndarray or StepFunction
            Survival function.
        """
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float32,
            )
        surv_df = self.model_.predict_surv_df(X)
        res = surv_df.values.T
        times = surv_df.index.values
        if return_array:
            return res
        return _array_to_step_function(times, res)


def model_def(trial, seed):
    """Define DeepSurv model for hyperparameter optimization.

    Parameters
    ----------
    trial : optuna.Trial
        Optuna trial object for hyperparameter suggestions.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    pipe : Pipeline
        Pipeline with preprocessing and DeepSurv model.
    needed_features : list
        List of features needed by the preprocessing step.
    """
    # dist = trial.suggest_categorical("dist", ["lognormal","loglogistic","weibull"])
    param_dict = {}
    n_layers = trial.suggest_int("n_layers", 1, 3)
    param_dict["n_layers"] = n_layers
    num_nodes = []

    lower_node_count = 100  # Increased from 16 to preserve information from 200 input features
    upper_node_count = 256

    layer_param = "n_nodes_l1"
    prev = trial.suggest_int(layer_param, lower_node_count, upper_node_count, log=True)
    param_dict[layer_param] = prev
    num_nodes.append(prev)
    for i in range(1, n_layers):
        layer_param = f"n_nodes_l{i + 1}"
        # The number of nodes can only stay the same or decrease
        nodes = trial.suggest_int(layer_param, lower_node_count, prev, log=True)
        prev = nodes
        param_dict[layer_param] = nodes
        num_nodes.append(nodes)
    dropout = trial.suggest_float("dropout", 0.0, 0.5)
    param_dict["dropout"] = dropout
    batch_norm = trial.suggest_categorical("batch_norm", [True, False])
    param_dict["batch_norm"] = batch_norm
    epochs = trial.suggest_int(
        "epochs", 300, 800
    )  # Adaptive from 1000 (early stopping handles convergence)
    param_dict["epochs"] = epochs
    batch_size = trial.suggest_categorical("batch_size", [128, 256, 512])
    param_dict["batch_size"] = batch_size
    val_fraction = 0.2
    param_dict["val_fraction"] = val_fraction

    prep, needed_features = prep_def_choose(trial, seed)
    model = DeepSurv(
        num_nodes=num_nodes,
        dropout=dropout,
        batch_norm=batch_norm,
        epochs=epochs,
        batch_size=batch_size,
        val_fraction=val_fraction,
        seed=seed,
        mlflow_logging=True,
    )
    mlflow.log_params(param_dict)
    pipe = Pipeline([("prep", prep), ("model", model)])
    mlflow.set_tag("modeltype", "DeepSurv")

    return pipe, needed_features
