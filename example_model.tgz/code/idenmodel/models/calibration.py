"""Calibration metrics and plots for survival models."""

import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.stats import chi2, norm
from sksurv.nonparametric import SurvivalFunctionEstimator


def _safe_survival_at(fn, time):
    """Evaluate a survival step function inside its supported domain.

    sksurv step functions raise when queried outside their domain. For
    calibration we treat times beyond the last supported point as the
    right-edge value, which keeps evaluation stable for test samples that
    slightly exceed the training support.
    """
    lower, upper = fn.domain
    clipped_time = np.clip(time, lower, upper)
    return fn(clipped_time)


def fix_risk_order(model, risk_score):
    """Ensure the returned risk score has the correct sign.

    Some models predict risk in the reverse ordering; this helper inverts
    the sign when the model indicates it does not use a positive risk score
    convention.
    """
    if hasattr(model, "steps"):
        model = model.steps[-1][1]
    if not getattr(model, "_predict_risk_score", True):
        return risk_score * -1
    return risk_score


def unstratified_calibration_plot(model, X, y, time_grid=None, conf_level=0.95):
    """Generate a calibration plot comparing predicted survival to Kaplan-Meier estimates."""
    if time_grid is None:
        time_grid = np.unique(y["time"][y["event_bool"] == 1])

    km = SurvivalFunctionEstimator(conf_level=conf_level, conf_type="log-log")
    km.fit(y)

    max_subset_time = km.unique_time_[-1]
    valid_time_grid = time_grid[time_grid <= max_subset_time]

    prob_survival, conf_int = km.predict_proba(valid_time_grid, return_conf_int=True)

    surv_funcs = model.predict_survival_function(X, return_array=False)
    surv_funcs = np.array([_safe_survival_at(fn, valid_time_grid) for fn in surv_funcs])
    mean_surv_func = np.mean(surv_funcs, axis=0)
    ses_surv_func = np.std(surv_funcs, axis=0, ddof=1) / np.sqrt(surv_funcs.shape[0])
    # only pointwise confidence intervals
    z = norm.ppf((1 - conf_level) / 2) * -1
    ci_half = z * ses_surv_func
    del surv_funcs, ses_surv_func

    df = pd.DataFrame(
        {
            "time": valid_time_grid,
            "pred_survival": mean_surv_func,
            "pred_survival_ci_lower": np.maximum(mean_surv_func - ci_half, 0),
            "pred_survival_ci_upper": np.minimum(mean_surv_func + ci_half, 1),
            "km_survival": prob_survival,
            "km_ci_lower": conf_int[0, :],
            "km_ci_upper": conf_int[1, :],
        }
    )

    return df


def stratified_calibration_plot(model, X, y, q=4, time_grid=None, conf_level=0.95):
    """Generate a stratified calibration plot within risk strata."""
    risk_scores = model.predict(X)
    risk_scores = fix_risk_order(model, risk_scores)

    groups = pd.qcut(risk_scores, q=q, labels=False)

    if time_grid is None:
        time_grid = np.unique(y["time"][y["event_bool"] == 1])

    dfs = []
    for g in np.unique(groups):
        mask = groups == g
        df = unstratified_calibration_plot(model, X[mask], y[mask], time_grid, conf_level)
        df["group"] = g
        dfs.append(df)

    df = pd.concat(dfs, ignore_index=True)
    return df


def d_calibration(model, X, y, group_count=10):
    """Perform D-calibration test for survival models."""
    # https://link.springer.com/article/10.1186/s12874-025-02671-6
    n = X.shape[0]
    surv_funcs = model.predict_survival_function(X, return_array=False)

    # PIT residuals S(T_i | x_i)
    pit = np.fromiter(
        (
            float(np.clip(_safe_survival_at(fn, t_i), 1e-12, 1.0))
            for fn, t_i in zip(surv_funcs, y["time"])
        ),
        dtype=float,
        count=n,
    )

    # Paper authors' binning rule: k = floor(u * G) + 1, with u == 1 mapped to G
    pit_bins = np.minimum((pit * group_count).astype(int) + 1, group_count)

    uncensored = np.asarray(y["event_bool"], dtype=bool)
    censored = ~uncensored

    e_k = np.full(group_count, n / group_count, dtype=float)
    n_k = np.bincount(pit_bins[uncensored] - 1, minlength=group_count).astype(float)

    if np.any(censored):
        cens_pit = pit[censored]
        cens_bins = pit_bins[censored]
        inv_pit = 1.0 / cens_pit

        # Contribution to the bin that contains the censored PIT residual
        self_contrib = np.where(
            cens_bins == 1,
            1.0,
            (cens_pit - (cens_bins - 1) / group_count) * inv_pit,
        )
        n_k += np.bincount(cens_bins - 1, weights=self_contrib, minlength=group_count)

        # Contribution to all previous bins, aggregated by PIT bin and added with a suffix sum
        prev_bin_contrib = np.bincount(
            cens_bins[cens_bins > 1] - 1,
            weights=(1.0 / group_count) * inv_pit[cens_bins > 1],
            minlength=group_count,
        )
        n_k += np.concatenate([np.cumsum(prev_bin_contrib[::-1])[::-1][1:], [0.0]])

    bin_df = pd.DataFrame(
        {
            "bin": np.arange(1, group_count + 1),
            "lower_edge": np.arange(0, group_count) / group_count,
            "upper_edge": np.arange(1, group_count + 1) / group_count,
            "observed_count": n_k,
            "expected_count": e_k,
        }
    )

    chi_stat = np.sum((n_k - e_k) ** 2 / e_k)
    p_val = chi2.sf(chi_stat, df=group_count - 1)

    return (bin_df, chi_stat, p_val)


def a_calibration(model, X, y, group_count=10):
    """Perform A-calibration test for survival models."""
    # https://link.springer.com/article/10.1186/s12874-025-02671-6

    n = X.shape[0]
    surv_funcs = model.predict_survival_function(X, return_array=False)

    # PIT residuals from model and A-calibration transform u = 1 - PIT
    pit = np.fromiter(
        (
            float(np.clip(_safe_survival_at(fn, t_i), 1e-12, 1.0))
            for fn, t_i in zip(surv_funcs, y["time"])
        ),
        dtype=float,
        count=n,
    )
    u = 1.0 - pit

    status = np.asarray(y["event_bool"], dtype=bool)

    # Empirical CDF H of transformed PIT residuals
    u_sorted = np.sort(u)

    def H(x):
        x_arr = np.atleast_1d(x)
        vals = np.searchsorted(u_sorted, x_arr, side="right") / n
        return vals if np.ndim(x) else float(vals[0])

    # Upper support limit where H plateaus (R code: quantile(H, probs=1), capped at 0.999)
    a = min(0.999, float(np.max(u)))
    interval_size = a / group_count

    # Observed event counts per interval: N_i
    lower_edges = np.arange(0, group_count) * interval_size
    upper_edges = np.arange(1, group_count + 1) * interval_size

    N = np.zeros(group_count, dtype=float)
    for i in range(group_count):
        lower = lower_edges[i]
        upper = upper_edges[i]
        mask = status & (u >= lower) & (u < upper)
        N[i] = np.sum(mask)

    # Expected counts: E_i = n * integral_{I_i} (1 - H(x)) / (1 - x) dx
    p = np.zeros(group_count, dtype=float)
    for i in range(group_count):
        lower = lower_edges[i]
        upper = upper_edges[i]
        if upper <= lower:
            p[i] = 0.0
            continue

        def integrand(x):
            return (1.0 - H(x)) / max(1e-12, 1.0 - x)

        p[i] = quad(
            integrand,
            lower,
            upper,
            limit=1000,
            epsrel=2 * np.finfo(float).eps ** 0.25,  # pylint: disable=maybe-no-member
        )[0]

    E = n * p

    # Pearson-type GOF statistic
    valid = E > 0
    chi_stat = np.sum(((N[valid] - E[valid]) ** 2) / E[valid])
    p_val = chi2.sf(chi_stat, df=group_count)

    bin_df = pd.DataFrame(
        {
            "bin": np.arange(1, group_count + 1),
            "lower_edge": lower_edges,
            "upper_edge": upper_edges,
            "observed_count": N,
            "expected_count": E,
            "expected_prob": p,
        }
    )

    return (bin_df, chi_stat, p_val)
