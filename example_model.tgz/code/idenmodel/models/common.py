"""Common model utilities for survival modeling and explanation helpers."""

import importlib
import logging
import warnings

import mlflow
import numpy as np
import pandas as pd
import plotly.express as px
import shap
from scipy.integrate import trapezoid
from sklearn.base import BaseEstimator, clone
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
from sklearn.utils._param_validation import HasMethods
from sklearn.utils.validation import check_is_fitted, validate_data
from sksurv.base import SurvivalAnalysisMixin
from sksurv.functions import StepFunction
from sksurv.nonparametric import CensoringDistributionEstimator
from sksurv.tree._criterion import get_unique_times  # pylint: disable=no-name-in-module
from sksurv.util import check_array_survival

import idenmodel.preprocessing as p

logger = logging.getLogger(__name__)


def prep_def_choose(trial, seed):
    """Select and configure a preprocessing module for an Optuna trial."""
    prepmodels = [m.__name__ for m in p.prep_modules]
    module = trial.suggest_categorical("prep_module", prepmodels)
    mlflow.log_param("prep_module", module)
    module = importlib.import_module(module)
    return module.prep_def(trial, seed)


def ipcw(time, delta, tau):
    """Compute inverse probability of censoring weights for a time horizon."""
    cdist = CensoringDistributionEstimator()
    data = np.array(list(zip(delta, time)), dtype=[("delta", bool), ("time", float)])
    cdist.fit(data)
    weights = np.zeros_like(time, dtype=float)
    # Censoring and Events after tau
    weights[time > tau] = 1 / cdist.predict_proba([tau])
    # Events before tau
    events_before_tau = (delta == 1) & (time < tau)
    if np.sum(events_before_tau) > 0:
        weights[events_before_tau] = 1 / cdist.predict_proba(time[events_before_tau])
    return weights


class IPCWModel(BaseEstimator, SurvivalAnalysisMixin):
    """Fit one binary model per time horizon and expose survival predictions."""

    _parameter_constraints = {
        "base_model": [HasMethods(["fit", "predict_proba"])],
        "taus": ["array-like"],
    }

    def __init__(self, *, base_model, taus: list):
        """Initialize the IPCW wrapper with a base model and evaluation times."""
        self.base_model = base_model
        self.taus = np.sort(taus)

    def _check_params(self):
        self._validate_params()

    def fit(self, X, y):
        """Fit one weighted classifier for each time horizon in ``taus``."""
        X, y = validate_data(
            self,
            X=X,
            y=y,
            reset=True,
            validate_separately=False,
            ensure_min_samples=2,
            dtype=np.float64,
        )
        self._check_params()
        event, time = check_array_survival(X, y)
        self.unique_times_ = get_unique_times(time, event)[0]
        models = []
        assert len(self.taus) > 0, "At least one tau must be provided"
        for tau in self.taus:
            weights = ipcw(time, event, tau)
            class_y = time > tau
            model = clone(self.base_model).fit(X, class_y, sample_weight=weights)
            models.append(model)
        self.models_ = models
        return self

    @property
    def _predict_risk_score(self):
        return True

    def predict(self, X, check_input=True):
        """Return a scalar risk score derived from the cumulative hazard."""
        check_is_fitted(self, "models_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        chf = self.predict_cumulative_hazard_function(X, check_input, return_array=True)
        return chf.sum(1)

    def predict_cumulative_hazard_function(self, X, check_input=True, return_array=False):
        """Return cumulative hazard functions or their array representation."""
        funs = self.predict_survival_function(X, check_input, return_array=False)
        for fun in funs:
            fun.y = -np.log(fun.y)
        if not return_array:
            return funs
        result = np.zeros((X.shape[0], len(self.unique_times_)))
        for i, fun in enumerate(funs):
            result[i, :] = fun(self.unique_times_)
        return result

    def predict_survival_function(self, X, check_input=True, return_array=False):
        """Return survival functions or a dense survival prediction array."""
        check_is_fitted(self, "models_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        result = np.zeros((X.shape[0], len(self.models_)))
        for i, model in enumerate(self.models_):
            truelabel = np.where(model.classes_)[0][0]
            result[:, i] = model.predict_proba(X)[:, truelabel]
        stepfuns = np.empty(X.shape[0], dtype=np.object_)
        for i in range(X.shape[0]):
            times = np.append(self.taus, self.unique_times_[-1])
            probs = np.append(result[i], result[i][-1])
            if 0 not in times:
                times = np.insert(times, 0, 0)
                probs = np.insert(probs, 0, 1)
            stepfuns[i] = StepFunction(x=times, y=probs)
        if not return_array:
            return stepfuns
        result = np.zeros((X.shape[0], len(self.unique_times_)))
        for i, stepfun in enumerate(stepfuns):
            result[i, :] = stepfun(self.unique_times_)
        return result


def aggregate_change(average_changes, aggregation_method, timestamps):
    """Aggregate time-wise change curves into a single importance score."""
    if aggregation_method == "sum_of_squares":
        return np.sum(average_changes.values**2, axis=1)
    if aggregation_method == "max_abs":
        return np.max(np.abs(average_changes.values), axis=1)
    if aggregation_method == "mean_abs":
        return np.mean(np.abs(average_changes.values), axis=1)
    if aggregation_method == "integral":
        return trapezoid(np.abs(average_changes.values), timestamps)


class ModelExplainer:
    """Build SHAP-based explanations for a trained preprocessing/model pipeline."""

    def __init__(
        self,
        modelpipe,
        l1_reg="num_features(25)",
        backgroundsample_size=100,
        seed=None,
        pipe_index=-1,
    ):
        """Initialize the explainer around a fitted pipeline."""
        self.modelpipe = modelpipe
        self.l1_reg = l1_reg
        self.transformed_X_ = None
        self.backgroundsample_size = backgroundsample_size
        self.seed = seed
        # Input of this step is used for SHAP
        self.pipe_index = pipe_index
        self.batch_size_ = 2048 * 10

    def fit(self, X):
        """Construct a representative background sample for SHAP."""
        X_modelin = self.modelpipe[: self.pipe_index].transform(X)
        # Generate background data using KMeans clustering
        # self.batch_size_  = X_modelin.shape[0]
        kmeans = KMeans(n_clusters=self.backgroundsample_size, random_state=42).fit(X_modelin)
        background_df = pd.DataFrame(kmeans.cluster_centers_, columns=X_modelin.columns)
        # For each column, replace center values with the closest real value in the data
        for col in X_modelin.columns:
            vals = X_modelin[col].values  # real values
            centers = background_df[col].values  # current center values
            # Find index of nearest real value for each center
            nearest_idx = np.abs(vals[:, None] - centers[None, :]).argmin(axis=0)
            background_df[col] = vals[nearest_idx]
        self.background_data_ = background_df
        self.valscaler_ = MinMaxScaler(feature_range=(-1, 1), clip=True)
        self.valscaler_.fit(self.background_data_)
        return self

    def _prepare_data(self, newX):
        """Validate and transform an input sample for explanation."""
        if self.background_data_ is None:
            raise ValueError("Model not fitted yet. Please call fit() before explain_pred().")
        if newX is not None and len(newX.shape) != 2:
            newX = pd.DataFrame([newX])
        # Transform the new observation
        if newX is not None:
            transformed_newobs = self.modelpipe[: self.pipe_index].transform(newX)
        else:
            transformed_newobs = self.background_data_

        return transformed_newobs

    def scaled_values(self, newX):
        """Return scaled feature values for the provided observation(s)."""
        newX = self._prepare_data(newX)
        transformed = self.valscaler_.transform(newX)
        # make it a dataframe
        transformed = pd.DataFrame(transformed, columns=self.get_feature_names_in_())
        transformed["observation"] = np.arange(transformed.shape[0])
        transformed = transformed.melt(
            id_vars=["observation"], var_name="variable", value_name="scaled_value"
        )
        return transformed

    def explain_pred(self, timegrid, newX, or_names=False):
        """Explain a prediction for one or more observations."""
        transformed_newobs = self._prepare_data(newX)
        return self._explain_single_obs(timegrid, transformed_newobs, or_names=or_names)

    def _predict_function(self, timegrid, X):
        batch_size = self.batch_size_ if self.batch_size_ is not None else X.shape[0]
        out = []

        # Preserve DataFrame structure if X is a DataFrame
        n = X.shape[0]
        for start in range(0, n, batch_size):
            stop = min(start + batch_size, n)
            X_batch = X.iloc[start:stop] if hasattr(X, "iloc") else X[start:stop]

            surv_funs = self.modelpipe[self.pipe_index].predict_survival_function(X_batch)
            out.append(np.vstack([fn(timegrid) for fn in surv_funs]))

        return np.vstack(out)

    # Fixing a bug in survshap (not necessary to transpose the results)
    # Based on shap_kernel in the package
    def _explain_single_obs(
        self,
        timegrid,
        new_observation=None,
        or_names=False,
        aggregation_method="integral",
    ):
        """Compute SHAP values for a single observation or the background set."""
        background_preds = self._predict_function(timegrid, self.background_data_)
        if new_observation is None:
            target_fun = background_preds
            new_observation = self.background_data_
        else:
            target_fun = self._predict_function(timegrid, new_observation)
        baseline_fun = np.mean(background_preds, axis=0)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=UserWarning)

            def predfun(X):
                return self._predict_function(timegrid, X)

            exp = shap.KernelExplainer(
                predfun, self.background_data_, seed=self.seed, gc_collect=True
            )
            shaps = exp.shap_values(new_observation, l1_reg=self.l1_reg)

        shaps_dfs = []
        variable_names = (
            self.get_or_feature_names_in_() if or_names else self.get_feature_names_in_()
        )
        for i in range(shaps.shape[0]):
            curres = shaps[i, :, :]
            if or_names:
                curres = self._match_out_to_in_names(curres)
            shaps_df = pd.DataFrame(curres, columns=[f"t{i}" for i, time in enumerate(timegrid)])
            shaps_df["aggregated_change"] = aggregate_change(shaps_df, aggregation_method, timegrid)
            shaps_df["observation"] = i
            shaps_df["variable"] = variable_names
            shaps_dfs.append(shaps_df)
        shaps_dfs = pd.concat(shaps_dfs, axis=0)
        return shaps_dfs, target_fun, baseline_fun

    def explain_dataset(self, timegrid, newX=None):
        """Explain a dataset and return aggregated feature importances."""
        transformed_newobs = self._prepare_data(newX)
        shaps_dfs, target_fun, baseline_fun = self._explain_single_obs(transformed_newobs)
        means = (
            shaps_dfs.drop(columns=["aggregated_change", "observation"])
            .groupby("variable")
            .agg(lambda x: x.abs().mean())
        )
        means["aggregated_change"] = aggregate_change(means, "integral", timegrid)
        means.sort_values("aggregated_change", ascending=False, inplace=True)
        means.reset_index(inplace=True)
        return means, baseline_fun, shaps_dfs

    def get_or_feature_names_in_(self):
        """Return the original feature names seen by the pipeline."""
        return self.modelpipe.feature_names_in_

    def get_feature_names_in_(self):
        """Return the transformed feature names produced by the pipeline."""
        return self.modelpipe[: self.pipe_index].get_feature_names_out(
            self.get_or_feature_names_in_()
        )

    def _match_out_to_in_names(self, shaps):
        """Map SHAP values from transformed features back to input features."""
        or_names = self.get_or_feature_names_in_()
        detail_names = pd.Series(self.get_feature_names_in_())
        masks = np.zeros((len(or_names), len(detail_names)), dtype=bool)
        for i, in_name in enumerate(or_names):
            masks[i, :] = detail_names.str.contains("__" + in_name)

        in_without_match = np.sum(masks, axis=1) == 0
        if np.sum(in_without_match) > 0:
            warnings.warn(
                "Some features in the input do not match the model data. They probably got removed."
            )
            print("Features without match: ", or_names[in_without_match])

        out_without_match = np.sum(masks, axis=0) == 0
        if np.sum(out_without_match) > 0:
            # we need to have 1 to n feature calculation
            warnings.warn("Some features in the model do not match the input data!")
            print("Features without match: ", detail_names[out_without_match])

        out_with_multiple_match = np.sum(masks, axis=0) > 1
        if np.sum(out_with_multiple_match) > 0:
            print(
                "Features with multiple matches: ",
                detail_names[out_with_multiple_match],
            )
            raise ValueError(
                "Some features in the model match multiple input features. This is not allowed."
            )

        return masks @ shaps


def bee_plot(timegrid, shaps_dfs, vals, n_topfeats=20):
    """Create a bee-swarm style SHAP visualization across time points."""
    var_order = (
        shaps_dfs.groupby("variable")["aggregated_change"]
        .mean()
        .sort_values(ascending=False)
        .index.tolist()
    )
    shap_tplt = (
        shaps_dfs.drop(columns=["aggregated_change"])
        .melt(id_vars=["observation", "variable"], var_name="time", value_name="value")
        .query("value!=0")
    )
    tplt = pd.merge(shap_tplt, vals, on=["observation", "variable"])
    time_df = pd.Series({f"t{i}": time for i, time in enumerate(timegrid)})
    tplt = tplt.merge(time_df.rename("time_val"), left_on="time", right_index=True)

    if len(var_order) > n_topfeats:
        var_order = var_order[:n_topfeats]
    tplt_filtered = tplt.query("variable in @var_order")

    n_vars = tplt_filtered["variable"].nunique()
    height = max(400, n_vars * 25)

    fig = px.scatter(
        tplt_filtered,
        x="value",
        y="variable",
        color="scaled_value",
        facet_col="time_val",
        category_orders={"variable": var_order},
        color_continuous_scale="Bluered",
        range_color=(-1, 1),
        labels={
            "value": "SHAP value",
            "scaled_value": "Feature value",
            "variable": "Feature",
        },
        height=height,
    )

    return fig, tplt_filtered


def plot_baseline_and_preds(baseline_fun, target_fun, timestamps):
    """Plot predicted survival curves together with the background baseline."""
    tplt_preds = pd.DataFrame(data=target_fun, columns=timestamps)
    tplt_preds["observation"] = np.arange(target_fun.shape[0])
    tplt_preds["Group"] = "Prediction"
    baseline_pred = pd.DataFrame(
        data=np.reshape(baseline_fun, (1, len(timestamps))), columns=timestamps
    )
    baseline_pred["observation"] = target_fun.shape[0] + 1
    baseline_pred["Group"] = "Background"
    tplt_preds = pd.concat([tplt_preds, baseline_pred], axis=0)
    tplt_preds = tplt_preds.melt(
        id_vars=["Group", "observation"], var_name="time", value_name="Survival"
    )

    fig = px.line(
        tplt_preds,
        x="time",
        y="Survival",
        color="Group",
        line_group="observation",
        labels={"time": "Time", "Survival": "Predicted Survival"},
    )

    def updatehue(trace):
        if "Prediction" in trace.name:
            trace.update(opacity=0.1)

    fig = fig.for_each_trace(updatehue)
    return fig, tplt_preds
