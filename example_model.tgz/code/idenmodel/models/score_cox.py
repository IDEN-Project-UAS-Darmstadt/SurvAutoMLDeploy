"""Cox model using existing score-derived features."""

import mlflow
from sklearn import set_config
from sklearn.pipeline import Pipeline
from sksurv.linear_model import CoxPHSurvivalAnalysis

from ..preprocessing import existing_scores

set_config(transform_output="pandas")


def model_def(trial, seed):
    """Build the Cox model pipeline for the existing-score feature set."""
    use_alpha = trial.suggest_categorical("use_alpha", [True, False])
    if use_alpha:
        alpha = trial.suggest_float("alpha", 1e-5, 0.1, log=True)
    else:
        alpha = 0
    model = CoxPHSurvivalAnalysis(alpha=alpha)
    prep, needed_features = existing_scores.prep_def(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params({"use_alpha": use_alpha, "alpha": alpha})
    mlflow.set_tag("modeltype", "Cox Regression (existing Scores)")

    return pipe, needed_features
