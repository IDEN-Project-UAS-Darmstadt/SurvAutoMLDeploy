"""Cox Proportional Hazards model with manual features."""

import mlflow
from sklearn import set_config
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline, make_pipeline
from sksurv.linear_model import CoxPHSurvivalAnalysis

set_config(transform_output="pandas")


def model_def(trial, seed):
    """Define the Cox Proportional Hazards model with optional L2 regularization."""
    use_alpha = trial.suggest_categorical("use_alpha", [True, False])
    if use_alpha:
        alpha = trial.suggest_float("alpha", 1e-5, 0.1, log=True)
    else:
        alpha = 0
    model = CoxPHSurvivalAnalysis(alpha=alpha)
    numeric_features = ["recipient_age", "donor_age"]

    pipe = make_pipeline(
        ColumnTransformer(
            [
                ("num", "passthrough", numeric_features),
            ],
            remainder="drop",
        ),
        SimpleImputer(strategy="median"),
    )

    pipe = Pipeline([("prep", pipe), ("model", model)])

    mlflow.log_params({"use_alpha": use_alpha, "alpha": alpha})
    mlflow.set_tag("modeltype", "Cox Regression (Age only)")

    return pipe, numeric_features
