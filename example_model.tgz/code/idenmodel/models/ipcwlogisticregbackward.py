"""IPCW logistic regression with backward variable selection.

Provides a scikit-learn compatible wrapper around an R `rms::lrm`
model using backward selection (via `fastbw`) and an IPCW wrapper.
"""

import mlflow
import numpy as np
import rpy2.robjects as ro
from rpy2.robjects import numpy2ri
from rpy2.robjects.packages import importr
from sklearn import set_config
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.utils.validation import check_is_fitted, validate_data

from .common import IPCWModel, prep_def_choose

rms = importr("rms")
survival = importr("survival")
stats = importr("stats")
base = importr("base")

set_config(transform_output="pandas")


class LogisticRegressionBackward(BaseEstimator):
    """Logistic regression with backward variable selection.

    Uses the R package `rms` (`lrm` + `fastbw`) to perform backward
    variable selection and returns a fitted model usable from Python.
    """

    def __init__(self, penalty=1):
        """Create the logistic regression selector.

        Args:
            penalty (float): Ridge penalty passed to `rms::lrm`.
        """
        self.penalty = penalty

    def fit(self, X, y, sample_weight=None):
        """Fit the backward-selected logistic regression on (X, y).

        The method converts inputs for R using rpy2, runs `rms::lrm` and
        `rms::fastbw` to select variables, and refits the reduced model.
        """
        X, y = validate_data(
            self,
            X=X,
            y=y,
            reset=True,
            validate_separately=False,
            ensure_min_samples=2,
            dtype=np.float64,
        )
        self.classes_ = np.unique(y)
        assert len(self.classes_) == 2
        trueval = self.classes_[0]
        y = y == trueval
        with ro.local_context() as lc:
            lc["w"] = ro.r("NULL")
            with (ro.default_converter + numpy2ri.converter).context():
                lc["X"] = ro.conversion.get_conversion().py2rpy(X)
                if sample_weight is not None:
                    lc["w"] = sample_weight
                lc["penalty"] = self.penalty
                lc["y"] = y
            lc["dat"] = ro.r("as.data.frame(X)")
            lc["f"] = ro.r("paste0('y~', paste0(colnames(dat), collapse='+'))")
            lc["f"] = ro.r("as.formula(f)")

            lc["fullmodel"] = ro.r("rms::lrm(f, data=dat[w!=0,], weights=w[w!=0], penalty=penalty)")
            # lc["model"] = ro.r("glm(y~., data=cbind(dat,y=y)
            # family=binomial, weights=w, control = list(maxit = 50))")
            # ro.r("print(summary(model))")
            lc["newf"] = ro.r("rms::fastbw(fullmodel)$names.kept")
            # ro.r("print(newf)")
            self._selected = list(map(lambda f: int(str(f)[1:]) - 1, lc["newf"]))
            assert len(self._selected) > 0, "At least one feature must be selected"
            lc["newf"] = ro.r("paste0('y~', paste0(newf, collapse='+'))")
            lc["newf"] = ro.r("as.formula(newf)")
            self.model_ = ro.r("rms::lrm(newf, data=dat[w!=0,], weights=w[w!=0], penalty=penalty)")
        return self

    @property
    def _predict_risk_score(self):
        return True

    def predict_proba(self, X):
        """Return predicted probabilities for each class.

        The first column corresponds to the positive class probability.
        """
        check_is_fitted(self, "model_")
        X = validate_data(
            self,
            X=X,
            reset=False,
            validate_separately=False,
            dtype=np.float64,
        )
        res = np.zeros((X.shape[0], 2))
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
            newdata = base.as_data_frame(X_r)
            res[:, 0] = rms.predict_lrm(self.model_, newdata=newdata, type="fitted")
        res[:, 1] = 1 - res[:, 0]
        return res

    def predict(self, X):
        """Return class predictions using a 0.5 threshold on probability.

        Uses a 0.5 threshold on predicted probability for the positive class.
        """
        return self.predict_proba(X)[:, 0] > 0.5


def model_def(trial, seed):
    """Define the Optuna model configuration for this estimator.

    Returns a scikit-learn Pipeline and a list of required features.
    """
    use_penalty = trial.suggest_categorical("use_penalty", [True, False])
    if use_penalty:
        penalty = trial.suggest_int("penalty", 1, 10**5, log=True)
    else:
        penalty = 0
    model = LogisticRegressionBackward(penalty=penalty)
    # taus is being set during training
    model = IPCWModel(base_model=model, taus=[])
    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])

    mlflow.log_params({"penalty": penalty, "use_penalty": use_penalty})
    mlflow.set_tag("modeltype", "IPCW Logistic Regression with Backward Selection")

    return pipe, needed_features
