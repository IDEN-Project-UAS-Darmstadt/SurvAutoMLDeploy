"""Backward-selected Cox regression wrappers built on `rms`."""

import warnings

import mlflow
import numpy as np
import rpy2.robjects as ro
from rpy2.rinterface_lib.embedded import RRuntimeError
from rpy2.robjects import numpy2ri
from rpy2.robjects.packages import importr
from sklearn import set_config
from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.utils._param_validation import StrOptions
from sklearn.utils.validation import check_is_fitted, validate_data
from sksurv.base import SurvivalAnalysisMixin
from sksurv.tree._criterion import get_unique_times  # pylint: disable=no-name-in-module
from sksurv.tree.tree import _array_to_step_function
from sksurv.util import check_array_survival

from .common import prep_def_choose

set_config(transform_output="pandas")

rms = importr("rms")
survival = importr("survival")
base = importr("base")


class CoxBackward(BaseEstimator, SurvivalAnalysisMixin):
    """Cox proportional hazards model with backward feature selection."""

    _parameter_constraints = {"rule": [StrOptions({"aic", "p"})]}

    def __init__(self, *, rule="aic"):
        """Initialise the estimator.

        Parameters
        ----------
        rule
            Selection rule passed to ``pec::selectCox``.
        """
        self.rule = rule

    def _check_params(self):
        self._validate_params()

    def fit(self, X, y):
        """Fit the model and select a reduced Cox specification."""
        X, y = validate_data(
            self,
            X=X,
            y=y,
            reset=True,
            validate_separately=False,
            ensure_min_samples=2,
            dtype=np.float64,
        )
        self._check_params()
        event, time = check_array_survival(X, y)
        self.unique_times_ = get_unique_times(time, event)[0]
        # ex. 0 -> 1
        self.time_shift_ = 1 - np.min(self.unique_times_)

        selected_features = []
        with ro.local_context() as lc:
            with (numpy2ri.converter).context():
                lc["X"] = ro.conversion.get_conversion().py2rpy(X)
                lc["time"] = time + self.time_shift_
                lc["event"] = event * 1
                lc["rule"] = self.rule
            lc["dat"] = ro.r("as.data.frame(X)")
            # set the colnames to V1, to Vn, where n is the number of features
            # we trust sklearn to have validated the input and fixed the order
            lc["colnames(dat)"] = ro.r("paste0('V', 1:ncol(dat))")
            lc["f"] = ro.r("paste0('Surv(time, event)~', paste0(colnames(dat), collapse='+'))")
            lc["f"] = ro.r("as.formula(f)")

            try:
                lc["newf"] = ro.r(
                    "pec::selectCox(f, data=cbind(dat, time=time, event=event), rule=rule)$In"
                )
                selected_indices = list(map(lambda f: int(str(f)[1:]) - 1, lc["newf"]))
                selected_features = list(self.feature_names_in_[selected_indices])
            except (RRuntimeError, ValueError, TypeError):
                warnings.warn(
                    "Feature selection failed (singularity, convergence or empty selection). "
                    "Falling back to a baseline model using the first available feature.",
                    UserWarning,
                )
                # Fallback if selectCox fails due to singularity
                selected_features = []

            if len(selected_features) == 0:
                # Fallback to a baseline model using the first available feature
                selected_features = ["V1"]
                selected_indices = [0]

            self._selected = selected_features
            lc["sel"] = ro.IntVector(np.asarray(selected_indices) + 1)
            cmd = "paste0('Surv(time, event)~', paste0(colnames(dat)[sel], collapse='+'))"
            lc["newf"] = ro.r(cmd)
            lc["newf"] = ro.r("as.formula(newf)")

            self.model_ = ro.r(
                "rms::cph(newf, data=cbind(dat, time=time, event=event), y=TRUE, surv=TRUE, x=TRUE)"
            )

        return self

    @property
    def _predict_risk_score(self):
        return True

    def predict(self, X, check_input=True):
        """Predict the linear risk score."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
            X_r.colnames = ro.StrVector([f"V{i + 1}" for i in range(X.shape[1])])
            res = rms.predict_cph(self.model_, newdata=base.as_data_frame(X_r), type="lp")
        return np.array(res)

    def predict_function(self, key, X, check_input=True, return_array=False):
        """Predict a survival-derived step function for each sample."""
        check_is_fitted(self, "model_")
        if check_input:
            X = validate_data(
                self,
                X=X,
                reset=False,
                validate_separately=False,
                dtype=np.float64,
            )
        with (ro.default_converter + numpy2ri.converter).context():
            X_r = ro.conversion.get_conversion().py2rpy(X)
            times_r = ro.conversion.get_conversion().py2rpy(self.unique_times_ + self.time_shift_)
        res = survival.summary_coxph(
            rms.survfit_cph(self.model_, newdata=base.as_data_frame(X_r)), times=times_r
        )
        with (ro.default_converter + numpy2ri.converter).context():
            res = np.transpose(res.rx2(key))
        if return_array:
            return res
        return _array_to_step_function(self.unique_times_, res)

    def predict_cumulative_hazard_function(self, X, check_input=True, return_array=False):
        """Predict cumulative hazard functions."""
        return self.predict_function("cumhaz", X, check_input, return_array)

    def predict_survival_function(self, X, check_input=True, return_array=False):
        """Predict survival functions."""
        return self.predict_function("surv", X, check_input, return_array)


def model_def(trial, seed):
    """Build the CoxBackward pipeline for a given Optuna trial."""
    model = CoxBackward()
    prep, needed_features = prep_def_choose(trial, seed)
    pipe = Pipeline([("prep", prep), ("model", model)])
    mlflow.set_tag("modeltype", "Cox Regression with Backward Selection")

    return pipe, needed_features
