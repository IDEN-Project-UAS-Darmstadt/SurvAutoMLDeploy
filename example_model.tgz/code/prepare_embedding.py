"""Evaluation module for survival models."""

from pathlib import Path
from tempfile import TemporaryDirectory

import click
import mlflow
import numpy as np
import pandas as pd
import plotly.express as px
import umap
from idenmodel.common import setup_logging
from idenmodel.preprocessing.common import find_icd10_columns, icd_10_cleaning, log_data
from sentence_transformers import SentenceTransformer
from sklearn import set_config
from sklearn.preprocessing import StandardScaler

set_config(transform_output="pandas")
logger = setup_logging("Embedding Preparation")


@click.command()
@click.option(
    "-o",
    "--output_dir",
    type=str,
    required=True,
    help="Output directory for the exported models.",
)
@click.option("-d", "--datafile", required=True, type=str, help="Path to the data CSV file.")
@click.option(
    "-c",
    "--catalogue",
    required=True,
    type=str,
    help="Path to the BIFG ICD10 catalogue xlsx file.",
)
@click.option(
    "-m",
    "--model_repo",
    type=str,
    default="zeroentropy/zembed-1",
    help="MLflow model repository for the embedding model.",
)
@click.option(
    "-r",
    "--model_revision",
    type=str,
    default="7bd85976f2dace4a97d99f8266d77679622a7e50",
    help="Model revision for the embedding model.",
)
@click.option(
    "-n",
    "--normalized_embeddings",
    type=bool,
    default=True,
    help="Flag to indicate whether to normalize the embeddings.",
)
def embedding(output_dir, datafile, catalogue, model_repo, model_revision, normalized_embeddings):
    """Prepare embeddings for the ICD10 data."""
    # Convert to absolute paths
    output_dir = str(Path(output_dir).resolve())
    logger.info(f"Output directory (absolute): {output_dir}")

    with mlflow.start_run(nested=True), TemporaryDirectory():
        # Read occuring ICD10 codes
        df = pd.read_csv(datafile)
        icd10_columns = find_icd10_columns(df)
        logger.info(f"Found {len(icd10_columns)} ICD10 columns: {icd10_columns}")
        mlflow.log_metric("num_icd10_columns", len(icd10_columns))
        mlflow.log_param("icd10_columns", icd10_columns)
        df = df.loc[:, icd10_columns]
        log_data(df, context="Embedding Prep")
        multinominals_sel = df.apply(lambda col: col.str.contains(";;")).any(axis=0)
        count = multinominals_sel.sum()
        logger.info(
            f"Found {count} multinominal ICD10 columns: {df.columns[multinominals_sel].tolist()}"
        )
        mlflow.log_metric("num_multinominal_icd10_columns", multinominals_sel.sum())
        mlflow.log_param("multinominal_icd10_columns", df.columns[multinominals_sel].tolist())
        codes = set()
        for col in df.columns[~multinominals_sel]:
            codes.update(df[col].dropna().unique())
        for col in df.columns[multinominals_sel]:
            split_codes = df[col].dropna().str.split(";;")
            for cell in split_codes:
                codes.update({code for code in cell if not pd.isnull(code)})
        logger.info(f"Found {len(codes)} unique ICD10 codes across all columns.")
        codes = set(icd_10_cleaning(list(codes)))
        logger.info(f"After cleaning, found {len(codes)} unique ICD10 codes.")
        mlflow.log_metric("num_unique_icd10_codes", len(codes))
        codes = pd.Series(list(codes), name="Code").sort_values().reset_index(drop=True).to_frame()

        # Read BIFG ICD10 catalogue
        icdcodes = pd.read_excel(
            catalogue,
            skiprows=4,
            usecols=[
                "Code",
                "Code Bezeichnung",
                "Gruppe Bezeichnung",
                "3steller Bez.",
                "4steller Bez.",
                "5steller Bez.",
            ],
        )
        icdcodes["Code"] = icd_10_cleaning(icdcodes["Code"])

        def create_full_text(row):
            parts = [row["Code"], row["Code Bezeichnung"]]
            additional_parts = [
                row["Gruppe Bezeichnung"],
                row["3steller Bez."],
                row["4steller Bez."],
                row["5steller Bez."],
            ]
            additional_parts = [str(s) for s in additional_parts if not pd.isnull(s)]
            if additional_parts:
                parts.append(f"({', '.join(additional_parts)})")
            return " ".join(parts)

        icdcodes["code_full_text"] = icdcodes.apply(
            lambda row: create_full_text(row),
            axis=1,
        )
        logger.info(f"Read {len(icdcodes)} entries from the BIFG ICD10 catalogue.")
        sample = icdcodes["code_full_text"].sample(n=3, random_state=111)
        logger.info(
            f"Sample of 3 ICD10 codes with full text descriptions:\n{sample.to_string(index=False)}"
        )
        manual_additions = {
            "ALTER": "Kontraindikation aufgrund des hohen Alters",
            "I84": "Hämorrhoiden ohne Komplikation, nicht näher bezeichnet",
            "Other": "Sonstige Diagnosen, die nicht mehr verfügbar sind",
        }
        manual_additions = pd.DataFrame(
            list(manual_additions.items()), columns=["Code", "code_full_text"]
        )
        all_icd_fulltext = pd.concat(
            [icdcodes[["Code", "code_full_text"]], manual_additions], ignore_index=True
        )
        logger.info(f"Adding manual entries: {manual_additions['Code'].tolist()}")

        # First direct mapping
        logger.info("Performing direct mapping of ICD10 codes to full text descriptions.")
        mapped_direct = pd.merge(codes, all_icd_fulltext, how="left", validate="1:1")[
            ["Code", "code_full_text"]
        ]
        unmapped_sel = mapped_direct["code_full_text"].isna()
        missing_codes = mapped_direct.loc[unmapped_sel, "Code"].drop_duplicates().sort_values()
        count = unmapped_sel.sum()
        missing_codes_to_sample = min(5, count)
        sample = missing_codes.sample(n=missing_codes_to_sample, random_state=111)
        logger.info(f"After direct mapping, {count} codes remain unmapped.")

        # Make the missing codes more general
        logger.info("Attempting to map remaining unmapped codes by reducing specification.")
        # reduce the specification by removing the last character
        missing_codes_mapping = pd.DataFrame(
            {
                "Code": missing_codes.to_numpy(),
                "Reduced_Code": icd_10_cleaning(missing_codes.str[:-1]),
            }
        )
        logger.info(
            "Mapping I84.9 to K64.9 for hemorrhoids without complication, not further specified."
        )
        # I84.9 should be K64.9, we add it manually
        missing_codes_mapping.loc[missing_codes_mapping["Code"] == "I84.9", "Reduced_Code"] = (
            "K64.9"
        )
        # Map the reduced codes to the full text descriptions
        missing_codes_mapping = (
            pd.merge(
                missing_codes_mapping,
                all_icd_fulltext,
                how="left",
                right_on="Code",
                left_on="Reduced_Code",
                validate="m:1",
            )
            .drop(columns=["Code_y"])
            .rename(columns={"Code_x": "Code"})
        )
        if missing_codes_mapping["code_full_text"].isna().sum() > 0:
            unmapped_ar = (
                missing_codes_mapping.loc[missing_codes_mapping["code_full_text"].isna(), "Code"]
                .drop_duplicates()
                .sort_values()
            )
            logger.error(
                f"After reduction {len(unmapped_ar)} unmapped codes: {unmapped_ar.tolist()}"
            )
            assert False, (
                "There are still unmapped codes after reduction. Please check the logs for details."
            )
        mlflow.log_table(missing_codes_mapping, "missing_codes_mapping.json")
        all_icd_fulltext_with_reductions = pd.concat(
            [all_icd_fulltext, missing_codes_mapping], ignore_index=True
        )

        # Second try mapping with the reduced codes
        mapped_second_try = pd.merge(
            codes, all_icd_fulltext_with_reductions, how="left", validate="1:1"
        )
        unmapped_sel = mapped_second_try["code_full_text"].isna()
        missing_codes = mapped_second_try.loc[unmapped_sel, "Code"].drop_duplicates().sort_values()
        assert len(missing_codes) == 0, (
            f"There are still unmapped codes after the second try: {missing_codes.tolist()}"
        )

        # Run model
        logger.info(f"Loading '{model_repo}' with revision '{model_revision}'.")
        model = SentenceTransformer(
            model_repo,
            revision=model_revision,
            trust_remote_code=True,
            model_kwargs={"torch_dtype": "bfloat16"},
        )
        dev = model.device
        logger.info(f"Model loaded on device: {dev}")
        batch_size = 1 if dev == "cpu" else 64
        mlflow.log_param("embedding_batch_size", batch_size)
        logger.info(f"Using batch size of {batch_size} for encoding based on device.")
        encoded = model.encode_document(
            (
                "The patient has been diagnosed with "
                + all_icd_fulltext_with_reductions["code_full_text"]
            ).tolist(),
            show_progress_bar=True,
            batch_size=batch_size,
            normalize_embeddings=normalized_embeddings,
        )
        mlflow.log_metric("embedding_dimension", encoded.shape[1])
        mlflow.log_metric("num_icd10_codes_embedded", encoded.shape[0])

        # Save results
        model_metadata = [model_repo, model_revision, normalized_embeddings]
        output = Path(output_dir) / "icd10_gm_embeddings.npz"
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        logger.info(f"Saving embeddings to: {output}")
        np.savez(
            str(output),
            matrix=encoded,
            codes=all_icd_fulltext_with_reductions["Code"].to_numpy(),
            model_metadata=np.array(model_metadata),
        )
        logger.info(f"Saved ICD10 embeddings with shape {encoded.shape} to '{output}'.")

        # Viz
        logger.info("Creating 2D UMAP visualization of the ICD10 embeddings.")
        n_neighbors = 15
        min_dist = 0.1
        reducer = umap.UMAP(
            n_neighbors=n_neighbors,
            min_dist=min_dist,
            n_components=2,
            random_state=42,
            verbose=True,
        )
        sc = StandardScaler()
        sc_tra = sc.fit_transform(encoded)
        embedding_2d = reducer.fit_transform(sc_tra)
        # text up to first (
        text = all_icd_fulltext_with_reductions["code_full_text"].str.split("(", n=1).str[0]
        viz_df = pd.DataFrame(
            {
                "x": embedding_2d[:, 0],
                "y": embedding_2d[:, 1],
                "code": all_icd_fulltext_with_reductions["Code"],
                "text": text,
                "n_neighbors": n_neighbors,
                "min_dist": min_dist,
            }
        )
        viz_df["chapter"] = viz_df["code"].str[0]
        mlflow.log_table(viz_df, "icd10_embeddings_viz_data.json")
        fig_plotly = px.scatter(
            viz_df,
            x="x",
            y="y",
            color="chapter",
            hover_name="code",
            hover_data={"text": True, "x": False, "y": False},
            title=f"ICD-10 Embeddings (Model: {model_repo})",
            labels={"chapter": "ICD-10 Kapitel"},
        )
        mlflow.log_figure(fig_plotly, "plots/embeddings_interactive.html")


if __name__ == "__main__":
    embedding()  # pylint: disable = no-value-for-parameter
