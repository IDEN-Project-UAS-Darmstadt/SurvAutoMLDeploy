"""Train and evaluate models on different data splits."""

import tempfile

import click
import mlflow
import pandas as pd
from idenmodel.preprocessing.common import convert_numeric_to_float, log_data
from sklearn import set_config
from sklearn.model_selection import train_test_split

set_config(transform_output="pandas")


def add_existing_params(id):
    """Copy parameters from an existing MLflow run into the current run.

    The function removes the `datafile` parameter before logging to avoid
    storing local file paths.
    """
    client = mlflow.client.MlflowClient()
    run_data = client.get_run(id)
    params = run_data.data.params
    del params["datafile"]
    mlflow.log_params(params)


@click.command()
@click.option("-m", "--modelname", required=True)
@click.option("-d", "--datafile", required=True)
@click.option("-c", "--cores", required=True, type=int)
@click.option("-s", "--seed", required=True, type=int)
@click.option("-p", "--testfraction", required=True, type=float)
@click.option("-g", "--evalgridsize", required=True, type=int)
@click.option("-t", "--trials", required=True, type=int)
@click.option("-i", "--do_importance", required=True, type=bool)
def train_eval(modelname, datafile, cores, seed, testfraction, evalgridsize, trials, do_importance):
    """Train and evaluate a single model on a train/test split.

    This command runs the `train` entry point for the training stage and
    then executes `eval` on the resulting trained models.
    """
    with mlflow.start_run(nested=True) as run:
        df = convert_numeric_to_float(pd.read_csv(datafile))
        log_data(df, context="All")
        mlflow.set_tag("step", "train_eval")
        train, test = train_test_split(
            df, test_size=testfraction, random_state=seed, stratify=df["event"]
        )
        log_data(train, context="Train")
        log_data(test, context="Test")
        with tempfile.NamedTemporaryFile() as trainfile, tempfile.NamedTemporaryFile() as testfile:
            train.to_csv(trainfile, index=False)
            test.to_csv(testfile, index=False)
            train_run = mlflow.projects.run(
                ".",
                "train",
                parameters={
                    "modelname": modelname,
                    "datafile": trainfile.name,
                    "cores": cores,
                    "seed": seed,
                    "evalgridsize": evalgridsize,
                    "trials": trials,
                },
                run_name=run.info.run_name + "-train",
                synchronous=True,
            )
            train_run_id = train_run.run_id
            logged_train_run = mlflow.get_run(train_run_id)
            o = logged_train_run.outputs.model_outputs
            # Run eval on the feature selected model and the all feature model
            for i, model in enumerate(o):
                modelid = model.model_id
                mlflow.projects.run(
                    ".",
                    "eval",
                    parameters={
                        "datafile": testfile.name,
                        "trainfile": trainfile.name,
                        "cores": cores,
                        "seed": seed,
                        "evalgridsize": evalgridsize,
                        "modelid": modelid,
                        "do_importance": do_importance,
                    },
                    run_name=run.info.run_name + f"-test-{i}",
                    synchronous=True,
                )


if __name__ == "__main__":
    train_eval()  # pylint: disable = no-value-for-parameter
